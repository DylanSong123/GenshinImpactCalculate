package data.main.database;

/**
 * incomeDatabase
 */
public class incomeDatabase {
	
}
