package data.main;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Weapon
 */
public class Weapon {
	public double[] data(int clasIndex, int nameIndex) {
		double[] weaponDates = null;

		weaponDates = database(clasIndex, nameIndex);
		return weaponDates;
	}

	private static String[] strArrs;

	private static double[] database(int clasIndex, int nameIndex) {
		double[] roleDates = null;
		String fileNameString = null;
		// 角色数据载入
		switch (clasIndex) {
			case 0:
				fileNameString = "data/saves/database/WeaponDatabase0.csv";
				break;
			case 1:
				fileNameString = "data/saves/database/WeaponDatabase1.csv";
				break;
			case 2:
				fileNameString = "data/saves/database/WeaponDatabase2.csv";
				break;
			case 3:
				fileNameString = "data/saves/database/WeaponDatabase3.csv";
				break;
			case 4:
				fileNameString = "data/saves/database/WeaponDatabase4.csv";
				break;
			default:
				fileNameString = "data/saves/database/WeaponDatabase0.csv";
				break;
		}

		FileInputStream fis = null;
		try {
			fis = new FileInputStream(fileNameString);// 加载路径
			int fileBytesNum = fis.available();//
			byte[] fileBytes = new byte[fileBytesNum];// 搬运工
			fis.read(fileBytes); // 返回字节数量
			String fileBytesString = new String(fileBytes);// 创建字节数量大小的String
			String str = fileBytesString; // 继承
			strArrs = str.split("Num");// 分割
		} catch (FileNotFoundException throwe) {
			throwe.printStackTrace();
		} catch (IOException throwe) {
			throwe.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException throwe) {
					throwe.printStackTrace();
				}
			}
		}
		// 数据选择
		// System.out.println("武器种类序号：" + clasIndex);
		// System.out.println("武器序号：" + nameIndex);
		String[] strTheRole = strArrs[nameIndex + 1].split(",");
		// for (int i = 0; i < strTheRole.length; i++) {
		// 	System.out.println("i: " + strTheRole[i]);
		// }
		roleDates = new double[strTheRole.length - 2];
		// System.out.println(strTheRole.length - 2);

		roleDates[0] = Double.parseDouble(strTheRole[2]);// 精炼
		roleDates[1] = Double.parseDouble(strTheRole[3]);// 攻击白字数值
		roleDates[2] = Double.parseDouble(strTheRole[4]);// 主词条攻击加成
		roleDates[3] = Double.parseDouble(strTheRole[5]);// 主词条防御加成
		roleDates[4] = Double.parseDouble(strTheRole[6]);// 主词条暴击率加成
		roleDates[5] = Double.parseDouble(strTheRole[7]);// 主词条爆伤加成
		roleDates[6] = Double.parseDouble(strTheRole[8]);// 主词条元素精通加成
		roleDates[7] = Double.parseDouble(strTheRole[9]);// 主词条物伤加成
		roleDates[8] = Double.parseDouble(strTheRole[10]);// 主词条元素充能加成
		roleDates[9] = Double.parseDouble(strTheRole[11]);// 特效 - 攻击加成
		roleDates[10] = Double.parseDouble(strTheRole[12]);// 特效 - 防御加成
		roleDates[11] = Double.parseDouble(strTheRole[13]);// 特效 - 暴击率加成
		roleDates[12] = Double.parseDouble(strTheRole[14]);// 特效 - 爆伤加成
		roleDates[13] = Double.parseDouble(strTheRole[15]);// 特效 - 攻速加成
		roleDates[14] = Double.parseDouble(strTheRole[16]);// 特效 - 增伤 - 平A
		roleDates[15] = Double.parseDouble(strTheRole[17]);// 特效 - 增伤 - 重击
		roleDates[16] = Double.parseDouble(strTheRole[18]);// 特效 - 增伤 - 下落
		roleDates[17] = Double.parseDouble(strTheRole[19]);// 特效 - 增伤 - E技能
		roleDates[18] = Double.parseDouble(strTheRole[20]);// 特效 - 暴击率加成 - E技能专属
		roleDates[19] = Double.parseDouble(strTheRole[21]);// 特效 - 增伤 - Q技能
		roleDates[20] = Double.parseDouble(strTheRole[22]);// 特效 - 增伤 - 物理伤害
		roleDates[21] = Double.parseDouble(strTheRole[23]);// 特效 - 增伤 - 元素伤害
		roleDates[22] = Double.parseDouble(strTheRole[24]);// 特效 - 增伤 - 整体伤害
		roleDates[23] = Double.parseDouble(strTheRole[25]);// 特效 - 单独攻击 - 基于攻击力
		roleDates[24] = Double.parseDouble(strTheRole[26]);// 特效 - 生命值加成
		roleDates[25] = Double.parseDouble(strTheRole[27]);// 特效 - 生命值转化攻击力

		return roleDates;
	}
}
