package data.main;

import data.gui.standard.SLabelText;

/**
 * StringToNum
 */
public class StringToNum {
	public StringToNum() {
	}

	/**
	 * doit String转Double[]，Base用
	 * 
	 * @param sLabelTexts
	 * @return Double[] 9个
	 */
	public static double[] doBase_A(SLabelText[] sLabelTexts) {
		// 初始化
		double[] dataNum = new double[9];
		// String转Double
		for (int i = 0; i <= 8; i++) {
			dataNum[i] = Double.parseDouble(sLabelTexts[i].textField.getText());
		}
		return dataNum;
	}

	public static double[] doPre_B(SLabelText[] sLabelTexts) {
		// 初始化
		double[] dataNum = new double[50];
		// String转Double
		for (int i = 0; i < 50; i++) {
			dataNum[i] = Double.parseDouble(sLabelTexts[i].textField.getText());
		}
		return dataNum;
	}

	public static double[] doWeapon_C(SLabelText[] sLabelTexts) {
		// 初始化
		double[] dataNum = new double[16];
		// String转Double
		for (int i = 0; i < 16; i++) {
			dataNum[i] = Double.parseDouble(sLabelTexts[i].textField.getText());
		}
		return dataNum;
	}
}
