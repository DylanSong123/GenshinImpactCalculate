package data.main;

import data.gui.frame.MainFrame;

/**
 * GSCMain-主程序入口
 */
public class GSCMain {
    public static void main(String[] args) {
        run();
    }

    private static void run() {
        new MainFrame();
    }
}