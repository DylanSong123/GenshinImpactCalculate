package data.main;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Role
 */
public class Role {
	public double[] data(int areaIndex, int roleIndex) {
		double[] roleDates = null;

		roleDates = database(areaIndex, roleIndex);
		return roleDates;
	}

	private static String[] strArrs;

	private static double[] database(int areaIndex, int roleIndex) {
		double[] roleDates = null;
		String fileNameString = null;
		// 角色数据载入
		switch (areaIndex) {
			case 0:
				fileNameString = "data/saves/database/RoleDatabase0.csv";
				break;
			case 1:
				fileNameString = "data/saves/database/RoleDatabase1.csv";
				break;
			case 2:
				fileNameString = "data/saves/database/RoleDatabase2.csv";
				break;
			default:
				fileNameString = "data/saves/database/RoleDatabase0.csv";
				break;
		}

		FileInputStream fis = null;
		try {
			fis = new FileInputStream(fileNameString);// 加载路径
			int fileBytesNum = fis.available();//
			byte[] fileBytes = new byte[fileBytesNum];// 搬运工
			fis.read(fileBytes); // 返回字节数量
			String fileBytesString = new String(fileBytes);// 创建字节数量大小的String
			String str = fileBytesString; // 继承
			strArrs = str.split("Num");// 分割
		} catch (FileNotFoundException throwe) {
			throwe.printStackTrace();
		} catch (IOException throwe) {
			throwe.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException throwe) {
					throwe.printStackTrace();
				}
			}
		}
		// 数据选择
		System.out.println("地区序号："+areaIndex);
		System.out.println("人物序号："+roleIndex);
		String[] strTheRole = strArrs[roleIndex + 1].split(",");
		// for (int i = 0; i < strTheRole.length; i++) {
		// 	System.out.println("i: " + strTheRole[i]);
		// }
		roleDates = new double[strTheRole.length-2];
		System.out.println(strTheRole.length-2);

		roleDates[0] = Double.parseDouble(strTheRole[2]);// 攻击加成
		roleDates[1] = Double.parseDouble(strTheRole[3]);// 防御加成
		roleDates[2] = Double.parseDouble(strTheRole[4]);// 生命加成
		roleDates[3] = Double.parseDouble(strTheRole[5]);// 暴击率加成
		roleDates[4] = Double.parseDouble(strTheRole[6]);// 爆伤加成
		roleDates[5] = Double.parseDouble(strTheRole[7]);// 元素加成
		roleDates[6] = Double.parseDouble(strTheRole[8]);// 物理加成
		roleDates[7] = Double.parseDouble(strTheRole[9]);// 元素充能加成
		roleDates[8] = Double.parseDouble(strTheRole[10]);// 元素精通加成
		roleDates[9] = Double.parseDouble(strTheRole[11]);// 平A属性 - 0 物理 - 1 元素
		roleDates[10] = Double.parseDouble(strTheRole[12]);// 平A类型 - 0 平A - 1 重击 - 2 下落

		/*
		roleDates[0] = Double.parseDouble(strTheRole[2]);// 生命力
		roleDates[1] = Double.parseDouble(strTheRole[3]);// 防御力
		roleDates[2] = Double.parseDouble(strTheRole[4]);// 自带攻击力
		roleDates[3] = Double.parseDouble(strTheRole[5]);// 突破攻击加成
		roleDates[4] = Double.parseDouble(strTheRole[6]);// 突破防御加成
		roleDates[5] = Double.parseDouble(strTheRole[7]);// 突破生命加成
		roleDates[6] = Double.parseDouble(strTheRole[8]);// 突破暴击率加成
		roleDates[7] = Double.parseDouble(strTheRole[9]);// 突破爆伤加成
		roleDates[8] = Double.parseDouble(strTheRole[10]);// 突破元素增伤家储层
		roleDates[9] = Double.parseDouble(strTheRole[11]);// 平A首刀
		roleDates[10] = Double.parseDouble(strTheRole[12]);// 平A尾刀
		roleDates[11] = Double.parseDouble(strTheRole[13]);// 平A段数
		roleDates[12] = Double.parseDouble(strTheRole[14]);// 重击伤害
		roleDates[13] = Double.parseDouble(strTheRole[15]);// 低空下落
		roleDates[14] = Double.parseDouble(strTheRole[16]);// 高空下落
		roleDates[15] = Double.parseDouble(strTheRole[17]);// E单段 - 是否防御力？- 0攻击力 - 1防御力
		roleDates[16] = Double.parseDouble(strTheRole[18]);// E单段
		roleDates[17] = Double.parseDouble(strTheRole[19]);// E爆炸 - 是否防御力？- 0攻击力 - 1防御力
		roleDates[18] = Double.parseDouble(strTheRole[20]);// E爆炸
		roleDates[19] = Double.parseDouble(strTheRole[21]);// Q单段 - 是否防御力？- 0攻击力 - 1防御力
		roleDates[20] = Double.parseDouble(strTheRole[22]);// Q单段
		roleDates[21] = Double.parseDouble(strTheRole[23]);// Q爆炸 - 是否防御力？- 0攻击力 - 1防御力
		roleDates[22] = Double.parseDouble(strTheRole[24]);// Q爆炸
		roleDates[23] = Double.parseDouble(strTheRole[25]);// E指标 - 1 参考单段 - 2 参考爆炸 - 3 综合计算
		roleDates[24] = Double.parseDouble(strTheRole[26]);// Q指标
		*/

		return roleDates;
	}
}
