package data.gui.frame;

import javax.swing.WindowConstants;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;

import data.diy.color.ColorUI;
import data.diy.font.FontUI;
import data.gui.panel.mainframepanel.menupanel.MenuPanel;
import data.gui.panel.mainframepanel.toppanel.TopPanel;
import data.gui.standard.SFrame;
import data.gui.standard.SPanel;

/**
 * MainFrame-主窗口
 */
public class MainFrame {
	public int frameWidth = 1600; // 窗口大小 - 宽度
	public int frameHeight = 900; // 窗口大小 - 高度

	public MainFrame() {
		// 窗口信息
		SFrame mainframe = new SFrame("Genshin Impact Calculation", 100, 50, frameWidth, frameHeight);
		mainframe.frame.setResizable(false);
		mainframe.frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); // 主窗口-关闭窗口事件
		mainframe.frame.setUndecorated(true);// 主窗口-没有标题栏
		// Font, Color
		ColorUIResource[] colors = new ColorUI().colors;
		FontUIResource[] fonts = new FontUI().fonts;
		// Panel
		TopPanel topPanel = new TopPanel(mainframe.frame, 0, 0, frameWidth, 35, colors, fonts);
		new MenuPanel(mainframe.frame, 5, 40, 50, 605, colors, fonts, topPanel);

		// 最后的准备
		new SPanel(mainframe.frame, 0, 0, 1600, 900, colors[0]);
		mainframe.frame.setVisible(true);
	}
}
