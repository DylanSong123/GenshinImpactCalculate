package data.gui.standard;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;

/**
 * SLabel
 */
public class SLabel {
    public JLabel label;
    public SLabel(JPanel panel, String string, int x, int y, int width, int height, ColorUIResource color, FontUIResource font) {
        label = new JLabel(string);
        label.setBounds(x, y, width, height);
        label.setForeground(color);
        label.setFont(font);
        panel.add(label);
    }
}
