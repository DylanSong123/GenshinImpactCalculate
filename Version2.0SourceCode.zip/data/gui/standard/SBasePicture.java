package data.gui.standard;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;


/**
 * SBasePicture
 */
public class SBasePicture {
	public JLabel label;
	public SBasePicture(JPanel panel, int x, int y, int width, int height, String imageRoad) {
		label = new JLabel(new ImageIcon(imageRoad));
		label.setBounds(x, y, width, height);
		panel.add(label);
	}
}