package data.gui.standard;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.plaf.ColorUIResource;

/**
 * SPanel
 */
public class SPanel {
    public JPanel panel;
	public SPanel(JFrame frame, int x, int y, int width, int height) {
        panel = new JPanel();
        panel.setBounds(x, y, width, height);
        frame.add(panel);
    }
    public SPanel(JFrame frame, int x, int y, int width, int height, ColorUIResource color) {
        panel = new JPanel();
        panel.setBounds(x, y, width, height);
        panel.setBackground(color);
        frame.add(panel);
    }
}
