package data.gui.standard;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;

public class SComboBox {
	public JLabel label;
	public JComboBox<String> comboBox;

	/**
	 * 
	 * @param panel
	 * @param textLabel
	 * @param x
	 * @param y
	 * @param width
	 * @param height
	 * @param listData     - new String[]{"香","雪"};
	 * @param gapX         - 间隔int
	 * @param widthBox
	 * @param heightBox
	 * @param colorText
	 * @param colorBoxFore
	 * @param colorBoxBack
	 * @param font
	 */
	public SComboBox(JPanel panel, String textLabel, int x, int y, int width, int height, String[] listData, int gapX,
			int widthBox, int heightBox, ColorUIResource colorText, ColorUIResource colorBoxFore,
			ColorUIResource colorBoxBack, FontUIResource font) {
		// 标签
		label = new JLabel(textLabel);
		label.setBounds(x, y, width, height);
		label.setForeground(colorText);
		label.setFont(font);
		panel.add(label);
		// 下拉栏
		comboBox = new JComboBox<String>(listData);
		comboBox.setForeground(colorBoxFore);
		comboBox.setBackground(colorBoxBack);
		comboBox.setFont(font);
		comboBox.setBounds(x + gapX, y, widthBox, heightBox);
		panel.add(comboBox);
	}
}
