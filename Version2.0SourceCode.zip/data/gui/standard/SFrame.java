package data.gui.standard;

import javax.swing.JFrame;

/**
 * SFrame-标准窗口
 */
public class SFrame {
    public JFrame frame;
    public SFrame(String strings, int x, int y, int width, int height) {
        frame = new JFrame(strings);
        frame.setLayout(null);
        frame.setBounds(x, y, width, height);
    }
}
