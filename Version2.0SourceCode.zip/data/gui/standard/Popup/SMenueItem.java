package data.gui.standard.Popup;

/**
 * SMenueItem
 */
public class SMenueItem {

	public SMenueItem() {
		
	}
}