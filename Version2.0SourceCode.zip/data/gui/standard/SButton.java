package data.gui.standard;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * SButton
 */
public class SButton {
	public JButton button;

	public SButton(JPanel panel, int x, int y, int width, int height) {
		button = new JButton();
		button.setBounds(x, y, width, height);
		panel.add(button);
	}

	public SButton(JPanel panel, String string, int x, int y, int width, int height) {
		button = new JButton();
		button.setText(string);
		button.setBounds(x, y, width, height);
		panel.add(button);
	}

	public SButton(JPanel panel, String string, int x, int y, int width, int height, ColorUIResource colorText, ColorUIResource colorBack,
			FontUIResource font) {
		button = new JButton();
		button.setText(string);
		button.setBounds(x, y, width, height);
		button.setForeground(colorText);
		button.setBackground(colorBack);
		button.setFont(font);
		// 隐藏边框
		// button.setBorderPainted(false);
		// button.setBorder(null);
		button.setFocusPainted(false);
		button.setContentAreaFilled(false);
		panel.add(button);
	}

	/**
	 * 按钮-三图标
	 * 
	 * @param panel
	 * @param x
	 * @param y
	 * @param width
	 * @param height
	 * @param imageNor     - 正常状态
	 * @param imageSuspend - 悬停状态
	 * @param imageClick   - 点击状态
	 */
	public SButton(JPanel panel, int x, int y, int width, int height, ImageIcon imageNor, Icon imageSuspend,
			ImageIcon imageClick) {
		button = new JButton();
		button.setIcon(imageNor);
		button.setBounds(x, y, width, height);
		// 隐藏边框
		button.setBorderPainted(false);
		button.setBorder(null);
		button.setFocusPainted(false);
		button.setContentAreaFilled(false);
		// 监听
		runListen(button, imageNor, imageSuspend, imageClick);
		//
		panel.add(button);
	}

	public static void runListen(JButton button, Icon iconNor, Icon iconSuspend, Icon iconClick) {
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent e) {// 正常的动作
				button.setIcon(iconNor);
			}

			@Override
			public void mouseEntered(MouseEvent e) {// 悬停的动作
				button.setIcon(iconSuspend);

			}

			@Override
			public void mousePressed(MouseEvent e) {// 点击的动作
				button.setIcon(iconClick);
			}

			@Override
			public void mouseReleased(MouseEvent e) {// 释放的动作
				button.setIcon(iconNor);
			}
		});
	}
}
