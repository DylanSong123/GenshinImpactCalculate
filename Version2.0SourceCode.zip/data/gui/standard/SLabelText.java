package data.gui.standard;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;

/**
 * SLabelText - 标准Label+TextField
 */
public class SLabelText {
	public JLabel label;
	public JTextField textField;

	/**
	 * 
	 * @param panel
	 * @param labelString     - 标签文字
	 * @param textFieldString - 输入框默认文字
	 * @param x
	 * @param y
	 * @param widthLabel
	 * @param height
	 * @param gapX
	 * @param widthText
	 * @param labelColor      - 标签文字颜色
	 * @param textStringColor - 输入框文字颜色
	 * @param textBackColor   - 输入框背景颜色
	 * @param labelFont       - 标签字体
	 * @param textFont        - 输入框文字字体
	 */
	public SLabelText(JPanel panel, String labelString, String textFieldString, int x, int y, int widthLabel,
			int height, int gapX, int textWidth, ColorUIResource labelColor, ColorUIResource textStringColor,
			ColorUIResource textBackColor, FontUIResource labelFont, FontUIResource textFont) {
		label = new JLabel(labelString);
		textField = new JTextField(textFieldString);
		// Label
		label.setFont(labelFont);
		label.setForeground(labelColor);
		label.setBounds(x, y, widthLabel, height);
		panel.add(label);
		// TextField
		textField.setFont(textFont);
		textField.setForeground(textStringColor);
		textField.setBackground(textBackColor);
		textField.setBounds(x + gapX, y, textWidth, height);
		panel.add(textField);
	}

	public SLabelText(JPanel panel, String labelString, String textFieldString, int x, int y, int widthLabel,
			int height, int gapX, int textWidth, ColorUIResource labelColor, ColorUIResource textStringColor,
			ColorUIResource textBackColor, FontUIResource labelFont, FontUIResource textFont, boolean ifbound) {
		label = new JLabel(labelString);
		textField = new JTextField(textFieldString);
		// Label
		label.setFont(labelFont);
		label.setForeground(labelColor);
		label.setBounds(x, y, widthLabel, height);
		panel.add(label);
		// TextField
		textField.setFont(textFont);
		textField.setForeground(textStringColor);
		textField.setBackground(textBackColor);
		textField.setBounds(x + gapX, y, textWidth, height);
		if (ifbound) {
			// 隐藏边框
			
			textField.setBorder(null);

		}
		panel.add(textField);
	}
}
