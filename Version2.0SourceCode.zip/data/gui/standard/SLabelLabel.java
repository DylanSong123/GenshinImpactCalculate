package data.gui.standard;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;

/**
 * SLabelLabel
 */
public class SLabelLabel {
	public JLabel label, labelShow;

	public SLabelLabel(JPanel panel, String string, int x, int y, int width, int height, int gapX,
			ColorUIResource color, FontUIResource font) {
		label = new JLabel(string);
		label.setBounds(x, y, width, height);
		label.setForeground(color);
		label.setFont(font);

		labelShow = new JLabel("Null");
		labelShow.setBounds(x + gapX, y, width, height);
		labelShow.setForeground(color);
		labelShow.setFont(font);
		panel.add(label);
		panel.add(labelShow);
	}

}
