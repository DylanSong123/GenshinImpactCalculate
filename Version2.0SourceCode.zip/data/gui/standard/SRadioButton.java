package data.gui.standard;

import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;

/**
 * SRadioButton
 */
public class SRadioButton {
	public ButtonGroup btnGroup;
	public JRadioButton radioButtonA, radioButtonB, radioButtonC, radioButtonD;

	public SRadioButton(JPanel panel, int x, int y, int width, int height, int gapX, String textA, String textB) {
		btnGroup = new ButtonGroup();
		radioButtonA = new JRadioButton(textA, true);
		radioButtonB = new JRadioButton(textB);

		radioButtonA.setBounds(x, y, width, height);
		radioButtonB.setBounds(x, y + 35, width, height);

		btnGroup.add(radioButtonA);
		btnGroup.add(radioButtonB);
		panel.add(radioButtonA);
		panel.add(radioButtonB);

	}

	public SRadioButton(JPanel panel, int x, int y, int width, int height, int gapX, String textA, String textB,
			ColorUIResource colorText, ColorUIResource colorBack, FontUIResource font) {
		btnGroup = new ButtonGroup();
		radioButtonA = new JRadioButton(textA, true);
		radioButtonB = new JRadioButton(textB);

		radioButtonA.setBounds(x, y, width, height);
		radioButtonB.setBounds(x, y + 35, width, height);

		radioButtonA.setBackground(colorBack);
		radioButtonA.setForeground(colorText);
		radioButtonB.setBackground(colorBack);
		radioButtonB.setForeground(colorText);

		radioButtonA.setFont(font);
		radioButtonB.setFont(font);

		btnGroup.add(radioButtonA);
		btnGroup.add(radioButtonB);
		panel.add(radioButtonA);
		panel.add(radioButtonB);

	}

	public SRadioButton(JPanel panel, int x, int y, int width, int height, int gapX, String textA, String textB,
			String textC, ColorUIResource colorText, ColorUIResource colorBack, FontUIResource font) {
		btnGroup = new ButtonGroup();
		radioButtonA = new JRadioButton(textA, true);
		radioButtonB = new JRadioButton(textB);
		radioButtonC = new JRadioButton(textC);

		radioButtonA.setBounds(x, y, width, height);
		radioButtonB.setBounds(x + gapX, y, width, height);
		radioButtonC.setBounds(x + gapX * 2, y, width, height);

		radioButtonA.setBackground(colorBack);
		radioButtonA.setForeground(colorText);
		radioButtonB.setBackground(colorBack);
		radioButtonB.setForeground(colorText);
		radioButtonC.setBackground(colorBack);
		radioButtonC.setForeground(colorText);

		radioButtonA.setFont(font);
		radioButtonB.setFont(font);
		radioButtonC.setFont(font);

		btnGroup.add(radioButtonA);
		btnGroup.add(radioButtonB);
		btnGroup.add(radioButtonC);
		panel.add(radioButtonA);
		panel.add(radioButtonB);
		panel.add(radioButtonC);
	}

	public SRadioButton(JPanel panel, int x, int y, int width, int height, int gapX, String textA, String textB,
			String textC, String textD, ColorUIResource colorText, ColorUIResource colorBack, FontUIResource font) {
		btnGroup = new ButtonGroup();
		radioButtonA = new JRadioButton(textA, true);
		radioButtonB = new JRadioButton(textB);
		radioButtonC = new JRadioButton(textC);
		radioButtonD = new JRadioButton(textD);

		radioButtonA.setBounds(x, y, width, height);
		radioButtonB.setBounds(x + gapX, y, width, height);
		radioButtonC.setBounds(x + gapX * 2, y, width, height);
		radioButtonD.setBounds(x + gapX * 3, y, width, height);

		radioButtonA.setBackground(colorBack);
		radioButtonA.setForeground(colorText);
		radioButtonB.setBackground(colorBack);
		radioButtonB.setForeground(colorText);
		radioButtonC.setBackground(colorBack);
		radioButtonC.setForeground(colorText);
		radioButtonD.setBackground(colorBack);
		radioButtonD.setForeground(colorText);

		radioButtonA.setFont(font);
		radioButtonB.setFont(font);
		radioButtonC.setFont(font);
		radioButtonD.setFont(font);

		btnGroup.add(radioButtonA);
		btnGroup.add(radioButtonB);
		btnGroup.add(radioButtonC);
		btnGroup.add(radioButtonD);

		panel.add(radioButtonA);
		panel.add(radioButtonB);
		panel.add(radioButtonC);
		panel.add(radioButtonD);
	}
}