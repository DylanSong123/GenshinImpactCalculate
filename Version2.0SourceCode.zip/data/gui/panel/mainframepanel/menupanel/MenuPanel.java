package data.gui.panel.mainframepanel.menupanel;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;

import data.gui.panel.mainframepanel.menupanel.listening.MenuPanelListen;
import data.gui.panel.mainframepanel.mmA_CalBase_A.CalBase_A;
import data.gui.panel.mainframepanel.mmB_CalPre_B.CalPre_B;
import data.gui.panel.mainframepanel.mmC_CalWeapon_C.CalWeapom_C;
import data.gui.panel.mainframepanel.toppanel.TopPanel;
import data.gui.standard.SButton;
import data.gui.standard.SPanel;

/**
 * MenuPanel-侧栏-菜单栏-宽度50，高度665
 */
public class MenuPanel {
    public JPanel panel;
	public CalBase_A calBase_A;
	public CalPre_B calPre_B;
	public CalWeapom_C calWeapom_C;
    public MenuPanel(JFrame frame, int x, int y, int width, int height, ColorUIResource[] colors,
            FontUIResource[] fonts, TopPanel topPanel) {
        SPanel sPanel = new SPanel(frame, x, y, width, height, colors[1]);
        sPanel.panel.setLayout(null);
        this.panel = sPanel.panel;
        // 基本计算器 - 基本面版计算伤害
        calBase_A = new CalBase_A(frame, 60, 40, frame.getWidth()-70, 550, colors, fonts);// 第一页 - 初级计算器
		calPre_B = new CalPre_B(frame, 60, 40, frame.getWidth()-70, 800, colors, fonts);//第二页 - 高级计算器
		calWeapom_C = new CalWeapom_C(frame, 60, 40, frame.getWidth()-70, 800, colors, fonts);//第三页 - 根据圣遗物对比各个武器
        // 各个页面的初始显示
        MainFramePanelShow.ready(this);
        // 所有页面
        JPanel[] panels = new JPanel[50];
		panels[0] = calBase_A.panelTop;
        panels[1] = calBase_A.panelA;
        panels[2] = calBase_A.panelB;
		panels[3] = calPre_B.panelTop;
		panels[4] = calPre_B.panelA;
		panels[5] = calPre_B.panelB;
		panels[6] = calWeapom_C.panelTop;
		panels[7] = calWeapom_C.panelA;
		panels[8] = calWeapom_C.panelB;
        // 控件
        SButton A = new SButton(panel, 5, 30, 40, 40,
                new ImageIcon("data/resources/mainicon/menuicon/num1px40grey200.png"),
                new ImageIcon("data/resources/mainicon/menuicon/num1px40grey200point.png"),
                new ImageIcon("data/resources/mainicon/menuicon/num1px40grey150point.png"));
        new MenuPanelListen(frame, this, A.button, 0, 2, panels, topPanel);//监听
        SButton B = new SButton(panel, 5, 100, 40, 40,
                new ImageIcon("data/resources/mainicon/menuicon/num2px40grey200.png"),
                new ImageIcon("data/resources/mainicon/menuicon/num2px40grey200point.png"),
                new ImageIcon("data/resources/mainicon/menuicon/num2px40grey150point.png"));
        new MenuPanelListen(frame, this, B.button, 3, 5, panels, topPanel);
        SButton C = new SButton(panel, 5, 170, 40, 40,
                new ImageIcon("data/resources/mainicon/menuicon/num3px40grey200.png"),
                new ImageIcon("data/resources/mainicon/menuicon/num3px40grey200point.png"),
                new ImageIcon("data/resources/mainicon/menuicon/num3px40grey150point.png"));
        new MenuPanelListen(frame, this, C.button, 6, 8, panels, topPanel);

    }
}

class MainFramePanelShow {
    public static void ready(MenuPanel menuPanel) {
        menuPanel.calBase_A.panelTop.setVisible(false);
        menuPanel.calBase_A.panelA.setVisible(false);
        //calBase_A.panelB.setVisible(false);
		// calPre_B.panelTop.setVisible(false);
		// calPre_B.panelA.setVisible(false);
		// calPre_B.panelB.setVisible(false);
		menuPanel.calWeapom_C.panelTop.setVisible(false);
		menuPanel.calWeapom_C.panelA.setVisible(false);
		menuPanel.calWeapom_C.panelB.setVisible(false);
    }
}