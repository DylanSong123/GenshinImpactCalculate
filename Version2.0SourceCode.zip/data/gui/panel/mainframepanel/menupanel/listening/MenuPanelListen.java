package data.gui.panel.mainframepanel.menupanel.listening;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import data.gui.panel.mainframepanel.menupanel.MenuPanel;
import data.gui.panel.mainframepanel.toppanel.TopPanel;

/**
 * MenuPanelListen - 左侧菜单栏【核心】 - 切换各个页面
 */
public class MenuPanelListen implements ActionListener {
    private JPanel[] allPanels;
    private int startIndex, endIndex;
    private JButton button;
	private JFrame frame;
	private int frameWidth, frameHeight;
	private TopPanel topPanel;
	private MenuPanel menuPanel;
    /**
     * 按键监听 - 切换页面
     * 
     * @param frame      - frame
     * @param button     - 点击按钮
     * @param startIndex - 开始序号（0开始）
     * @param endIndex   - 结束序号
     * @param allPanels  - 所有页面
     */
    public MenuPanelListen(JFrame frame, MenuPanel menuPanel, JButton button, int startIndex, int endIndex, JPanel[] allPanels, TopPanel topPanel) {
        this.button = button;
        this.allPanels = allPanels;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
		this.frame = frame;
		this.topPanel = topPanel;
		this.menuPanel = menuPanel;
		//frame宽度
		
		if(startIndex>=0 && endIndex<=2){
			frameWidth = 830;
			frameHeight = 650;
		}else if (startIndex>=3 && endIndex<=5){
			frameWidth = 1600;
			frameHeight = 900;
		}else if (startIndex>=6 && endIndex<=8){
			frameWidth = 1600;
			frameHeight = 900;
		}
        // 按键监听
        button.addActionListener(this);
    }

    /**
     * 按键监听 - 切换页面
     * 
     * @param e
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == button) {
            for (int i = 0; i < allPanels.length; i++) {
                if ((i < startIndex || i > endIndex) && (allPanels[i] != null)) {
                    allPanels[i].setVisible(false);
                } else if ((i >= startIndex && i <= endIndex) && (allPanels[i] != null)) {
                    allPanels[i].setVisible(true);
                }
            }
			frame.setSize(frameWidth, frameHeight);
			
			topPanel.panel.setSize(frameWidth, 35);
			int baseX = frameWidth - 100;
			topPanel.closeButton.button.setBounds(baseX + 67, 7, 20, 20);
			topPanel.minButton.button.setBounds(baseX + 37, 7, 20, 20);
			topPanel.setButton.button.setBounds(baseX + 7, 7, 20, 20);
			topPanel.sBasePicture.label.setLocation(frameWidth-100, 2);
			menuPanel.calBase_A.panelTop.setSize(frameWidth-65, 50);
        }
    }
}