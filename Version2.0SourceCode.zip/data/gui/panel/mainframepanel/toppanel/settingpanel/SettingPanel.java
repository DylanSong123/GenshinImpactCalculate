package data.gui.panel.mainframepanel.toppanel.settingpanel;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.Desktop;
import java.net.URI;
import java.net.URISyntaxException;
/**
 * SettingPanel
 */
public class SettingPanel {
	public SettingPanel(JFrame frame, ColorUIResource[] colors, FontUIResource[] fonts) {

		// 创建 弹出菜单 对象
		JPopupMenu popupMenu = new JPopupMenu();

		// 主题色彩
		// 1
		JMenu themeMenu = new JMenu("主题色彩（下次启动生效）");
		themeMenu.setFont(fonts[8]);
		popupMenu.add(themeMenu);
		// 2
		JMenuItem dayItem = new JMenuItem("白色主题（还没做）");
		dayItem.setFont(fonts[7]);
		JMenuItem nightItem = new JMenuItem("黑色主题");
		nightItem.setFont(fonts[7]);
		themeMenu.add(dayItem);
		themeMenu.add(nightItem);
		//
		popupMenu.addSeparator(); // 添加一条分隔符

		// 关于
		// 1
		JMenu aboutMenu = new JMenu("关于");
		aboutMenu.setFont(fonts[8]);
		popupMenu.add(aboutMenu);
		// 2
		JMenuItem authorItem = new JMenuItem("作者：米游社@秋曦QY");
		authorItem.setFont(fonts[7]);
		JMenuItem versionItem = new JMenuItem("版本:Version_0.9");
		versionItem.setFont(fonts[7]);
		JMenuItem downloadItem = new JMenuItem("Github下载地址（点击打开浏览器链接）");
		downloadItem.setFont(fonts[7]);
		aboutMenu.add(authorItem);
		aboutMenu.add(versionItem);
		aboutMenu.add(downloadItem);
		// 监听
		downloadItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Desktop desktop = Desktop.getDesktop();
				try {
					desktop.browse(new URI("https://github.com/DylanSong123/GenshinImpactCalculate/releases"));
				} catch (IOException | URISyntaxException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		//

		popupMenu.show(frame, frame.getWidth() - 200, 30);
	}
}