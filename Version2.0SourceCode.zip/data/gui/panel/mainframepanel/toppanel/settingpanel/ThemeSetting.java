package data.gui.panel.mainframepanel.toppanel.settingpanel;

public class ThemeSetting {
	public ThemeSetting() {
		
	}
}
