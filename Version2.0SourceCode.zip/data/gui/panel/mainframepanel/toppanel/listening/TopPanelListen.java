package data.gui.panel.mainframepanel.toppanel.listening;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Point;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;

import data.gui.panel.mainframepanel.toppanel.settingpanel.SettingPanel;

/**
 * TopPanelListen - 顶栏监听
 */
public class TopPanelListen implements ActionListener {
	private int functionNum;
	private JButton button;
	private JFrame frame;
	private JPanel panel;
	private Point draggingAnchor = null;
	private ColorUIResource[] colors;
	private FontUIResource[] fonts;
	/**
	 * 顶栏按钮监听
	 * 
	 * @param frame
	 * @param panel
	 * @param button
	 * @param functionNum -1：关闭程序 -2：最大化-没功能 -3：最小化 -4：设置界面
	 */
	public TopPanelListen(JFrame frame, JPanel panel, JButton button, int functionNum, ColorUIResource[] colors,
			FontUIResource[] fonts) {
		// 继承
		this.functionNum = functionNum;
		this.button = button;
		this.frame = frame;
		this.panel = panel;
		this.colors = colors;
		this.fonts = fonts;
		// 面板拖动

		// 按钮
		button.addActionListener(this);
	}

	/**
	 * 窗口拖动监听
	 * 
	 * @param frame
	 * @param panel
	 */
	public TopPanelListen(JFrame frame, JPanel panel) {
		// 继承
		this.frame = frame;
		this.panel = panel;
		// 窗口拖动
		this.panel.addMouseMotionListener(new MouseAdapter() {// 监听位置
			public void mouseMoved(MouseEvent e) {
				draggingAnchor = new Point(e.getX(), e.getY());
			}

			public void mouseDragged(MouseEvent e) {// 移动位置
				frame.setLocation(e.getLocationOnScreen().x - draggingAnchor.x,
						e.getLocationOnScreen().y - draggingAnchor.y);
			}
		});
	}

	/**
	 * TopPanelListen 顶栏按钮监听Action
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == button) {
			switch (functionNum) {
				case 1:// 关闭程序
					frame.setVisible(false);
					frame.dispose();
					System.exit(0);
					break;
				case 2:// 最大化-暂空

					break;
				case 3:// 最小化
					frame.setExtendedState(JFrame.ICONIFIED);
					break;
				case 4:// 设置
					new SettingPanel(frame, colors, fonts);
					break;
				default:
					break;
			}
		}
	}
}
