package data.gui.panel.mainframepanel.toppanel;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;

import data.gui.panel.mainframepanel.toppanel.listening.TopPanelListen;
import data.gui.standard.SBasePicture;
import data.gui.standard.SButton;
import data.gui.standard.SLabel;
import data.gui.standard.SPanel;

/**
 * TopPanel-顶栏
 */
public class TopPanel {
	public JPanel panel;
	public SButton closeButton, minButton, setButton;
	public SBasePicture sBasePicture;
	public TopPanel(JFrame frame, int x, int y, int width, int height, ColorUIResource[] colors, FontUIResource[] fonts) {
		SPanel sPanel = new SPanel(frame, x, y, width, height, colors[1]);
		sPanel.panel.setLayout(null);
		this.panel = sPanel.panel;

		// 面板拖动监听
		new TopPanelListen(frame, panel);
		// 控件
		//中部标题
		new SLabel(panel, "原神计算器集", 20, 5, 300, 30, colors[4], fonts[8]);//width/20*9
		// 按钮坐标基准点
		int baseX = width - 100;
		// 关闭按钮
		closeButton = new SButton(panel, baseX + 67, 7, 20, 20,
				new ImageIcon("data/resources/mainicon/topicon/close20pxred.png"),
				new ImageIcon("data/resources/mainicon/topicon/close20pxred2.png"),
				new ImageIcon("data/resources/mainicon/topicon/close20px.png"));
		new TopPanelListen(frame, this.panel, closeButton.button, 1, colors, fonts);// 关闭按钮监听
		// 最小化按钮
		minButton = new SButton(panel, baseX + 37, 7, 20, 20,
				new ImageIcon("data/resources/mainicon/topicon/minimize20px.png"),
				new ImageIcon("data/resources/mainicon/topicon/minimize20pxred.png"),
				new ImageIcon("data/resources/mainicon/topicon/minimize20pxwhite.png"));
		new TopPanelListen(frame, this.panel, minButton.button, 3, colors, fonts);// 关闭按钮监听
		// 设置按钮
		setButton = new SButton(panel, baseX + 7, 7, 20, 20,
				new ImageIcon("data/resources/mainicon/topicon/set20px.png"),
				new ImageIcon("data/resources/mainicon/topicon/set20pxred.png"),
				new ImageIcon("data/resources/mainicon/topicon/set20pxwhite.png"));
		new TopPanelListen(frame, this.panel, setButton.button, 4, colors, fonts);// 关闭按钮监听
		// 背景绘制
		background(panel, width);
	}

	public void background(JPanel panel, int width) {
		sBasePicture = new SBasePicture(panel, width-100, 2, 98, 30, "data/resources/mainicon/topicon/background1_30px_RGB100.png");
	}
}
