package data.gui.panel.mainframepanel.mmC_CalWeapon_C;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import data.diy.color.ColorUI;
import data.diy.font.FontUI;
import data.gui.standard.SButton;
import data.gui.standard.SComboBox;
import data.gui.standard.SLabel;
import data.gui.standard.SLabelText;
import data.gui.standard.SPanel;
import data.main.Role;
import data.main.StringToNum;
import data.main.Weapon;

public class CalWeapom_C {

	public JPanel panelTop, panelA, panelB;
	private String[] roleAreaStrings, roleNameStrings, weaponClasStrings;
	private SComboBox roleAreaCB, roleNameCB, weaponClasCB;
	private SButton calButton;
	private CalButtonListen calButtonListen = null;

	public CalWeapom_C(JFrame frame, int x, int y, int width, int height, ColorUIResource[] colors,
			FontUIResource[] fonts) {
		// 双面板控制
		int gapX = width / 3;
		// 面板
		SPanel sPanelTop = new SPanel(frame, x, y, width + 5, 50, colors[1]);
		sPanelTop.panel.setLayout(null);
		this.panelTop = sPanelTop.panel;
		SPanel sPanelA = new SPanel(frame, x, y + 55, gapX, height, colors[1]);// 主面板
		sPanelA.panel.setLayout(null);
		this.panelA = sPanelA.panel;
		SPanel sPanelB = new SPanel(frame, x + gapX + 5, y + 55, width - gapX, height, colors[1]);// 次面板
		sPanelB.panel.setLayout(null);
		this.panelB = sPanelB.panel;
		// 控件
		SLabelText[] sLabelTexts = new SLabelText[16];
		// 主标题
		new SLabel(this.panelTop, "3：基于已有圣遗物的各武器对比计算器（数值仅供对比参考）", 20, 10, 700, 30, colors[4], fonts[9]);
		// 分控件 - 右面板
		int sumX = 370;
		int sumY = 500;
		// 计算按钮
		calButton = new SButton(this.panelA, "计算", sumX, sumY, 130, 100, colors[4], colors[3], fonts[11]);
		new SLabel(this.panelB, "经典普通攻击对比", 200, 20, 200, 30, colors[4], fonts[7]);
		new SLabel(this.panelB, "元素技能攻击对比", 700, 20, 200, 30, colors[4], fonts[7]);
		// 画板工具
		// DoPaint dopaint = new DoPaint(this.panelB,10, 10 , 200, 200, new double[]
		// dd);

		// 分控件 - 左面板
		sumX = 50;
		sumY = -10;
		int gapY = 35;
		// 1角色地区
		roleAreaStrings = new String[] { "蒙德", "璃月", "稻妻", "待添加" };
		roleAreaCB = new SComboBox(this.panelA, "角色地区", sumX, sumY += 35, 100, 30, roleAreaStrings, 150, 150, 35,
				colors[4], colors[4], colors[1], fonts[9]);

		int finalX = sumX;
		int finalY = sumY + 35;
		roleAreaCB.comboBox.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				// 只处理选中的状态
				if (e.getStateChange() == ItemEvent.SELECTED) {
					if (roleAreaCB.comboBox.getSelectedIndex() == 0) {
						// roleNameStrings = roleMengDe;
						roleNameStrings = new dataIO().dataIO_Role_A();
						panelA.remove(roleNameCB.comboBox);
						roleNameCB = new SComboBox(panelA, "角色名称", finalX, finalY, 100, 30, roleNameStrings, 150, 150,
								35, colors[4], colors[4], colors[1], fonts[9]);
								if(calButtonListen.hitClass_1!=null){
									panelB.remove(calButtonListen.damageClass_1.label);
									panelB.remove(calButtonListen.hitClass_1.label);
								}
						calButton.button.removeActionListener(calButtonListen);
						calButtonListen = new CalButtonListen(calButton, sLabelTexts, roleAreaCB, roleNameCB,
								weaponClasCB, panelB);


					} else if (roleAreaCB.comboBox.getSelectedIndex() == 1) {
						// roleNameStrings = new String[] { "璃月人A", "璃月人B", "璃月人C" };
						roleNameStrings = new dataIO().dataIO_Role_B();
						panelA.remove(roleNameCB.comboBox);
						
						roleNameCB = new SComboBox(panelA, "角色名称", finalX, finalY, 100, 30, roleNameStrings, 150, 150,
								35, colors[4], colors[4], colors[1], fonts[9]);
								if(calButtonListen.hitClass_1!=null){
									panelB.remove(calButtonListen.damageClass_1.label);
									panelB.remove(calButtonListen.hitClass_1.label);
								}
						calButton.button.removeActionListener(calButtonListen);
						calButtonListen = new CalButtonListen(calButton, sLabelTexts, roleAreaCB, roleNameCB,
								weaponClasCB, panelB);

					} else if (roleAreaCB.comboBox.getSelectedIndex() == 2) {
						// roleNameStrings = new String[] { "稻妻人A", "稻妻人B", "稻妻人C" };
						roleNameStrings = new dataIO().dataIO_Role_C();
						panelA.remove(roleNameCB.comboBox);

						roleNameCB = new SComboBox(panelA, "角色名称", finalX, finalY, 100, 30, roleNameStrings, 150, 150,
								35, colors[4], colors[4], colors[1], fonts[9]);
								if(calButtonListen.hitClass_1!=null){
									panelB.remove(calButtonListen.damageClass_1.label);
									panelB.remove(calButtonListen.hitClass_1.label);
								}
						calButton.button.removeActionListener(calButtonListen);
						calButtonListen = new CalButtonListen(calButton, sLabelTexts, roleAreaCB, roleNameCB,
								weaponClasCB, panelB);

					} else if (roleAreaCB.comboBox.getSelectedIndex() == 3) {
						roleNameStrings = new String[] { "等待更新" };
						panelA.remove(roleNameCB.comboBox);
						
						roleNameCB = new SComboBox(panelA, "角色名称", finalX, finalY, 100, 30, roleNameStrings, 150, 150,
								35, colors[4], colors[4], colors[1], fonts[9]);
								if(calButtonListen.hitClass_1!=null){
									panelB.remove(calButtonListen.damageClass_1.label);
									panelB.remove(calButtonListen.hitClass_1.label);
								}
						calButton.button.removeActionListener(calButtonListen);
						calButtonListen = new CalButtonListen(calButton, sLabelTexts, roleAreaCB, roleNameCB,
								weaponClasCB, panelB);

					}

					System.out.println("选中: " + roleAreaCB.comboBox.getSelectedIndex() + " = "
							+ roleAreaCB.comboBox.getSelectedItem());
				}
			}
		});
		// 2角色名字
		roleNameStrings = new dataIO().dataIO_Role_A();
		roleNameCB = new SComboBox(this.panelA, "角色名称", sumX, sumY += 35, 100, 30, roleNameStrings, 150, 150, 35,
				colors[4], colors[4], colors[1], fonts[9]);
		// ========================================================================================
		// 3武器类型
		weaponClasStrings = new String[] { "单手剑", "双手剑", "弓箭", "长枪", "法器" };
		weaponClasCB = new SComboBox(this.panelA, "武器类型", sumX, sumY += 35, 100, 30, weaponClasStrings, 150, 150, 35,
				colors[4], colors[4], colors[1], fonts[9]);

		// 5圣遗物面板-套装
		new SLabel(this.panelA, "圣遗物套装效果", sumX, sumY += gapY + 15, 200, 30, colors[4], fonts[9]);
		sLabelTexts[0] = new SLabelText(this.panelA, "攻击加成%", "0.0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[1] = new SLabelText(this.panelA, "暴击率加成%", "0.0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[2] = new SLabelText(this.panelA, "爆伤加成%", "0.0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[3] = new SLabelText(this.panelA, "物理增伤加成%", "0.0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[4] = new SLabelText(this.panelA, "元素增伤加成%", "0.0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[12] = new SLabelText(this.panelA, "平A增伤加成%", "0.0", sumX, sumY += gapY, 200, 30, 200, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[13] = new SLabelText(this.panelA, "重击增伤加成%", "0.0", sumX, sumY += gapY, 200, 30, 200, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[14] = new SLabelText(this.panelA, "下落增伤加成%", "0.0", sumX, sumY += gapY, 200, 30, 200, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[15] = new SLabelText(this.panelA, "生命值加成%", "0.0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		// 6圣遗物面板-总词条
		new SLabel(this.panelA, "圣遗物总体加成", sumX, sumY += gapY + 15, 200, 30, colors[4], fonts[9]);
		sLabelTexts[5] = new SLabelText(this.panelA, "生命值+", "0.0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[6] = new SLabelText(this.panelA, "攻击力+", "0.0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[7] = new SLabelText(this.panelA, "防御力+", "0.0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[8] = new SLabelText(this.panelA, "暴击率+%", "0.0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[9] = new SLabelText(this.panelA, "暴击伤害%+", "0.0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[10] = new SLabelText(this.panelA, "物理增伤%+", "0.0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[11] = new SLabelText(this.panelA, "元素增伤%+", "0.0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);

		// 计算按钮初始监听
		calButtonListen = new CalButtonListen(calButton, sLabelTexts, roleAreaCB, roleNameCB, weaponClasCB,
				this.panelB);

	}
}

/**
 * CalButtonListen - 计算按钮监听
 */
class CalButtonListen implements ActionListener {

	private JButton button;
	private SLabelText[] sLabelTexts;
	private SComboBox roleAreaCB, roleNameCB, weaponClasCB;
	private JPanel panel;
	ColorUIResource[] colors;
	FontUIResource[] fonts;
	/**
	 * 
	 * @param sbutton 计算按键
	 */
	public CalButtonListen(SButton sbutton, SLabelText[] sLabelTexts, SComboBox roleAreaCB, SComboBox roleNameCB,
			SComboBox weaponClasCB, JPanel panel) {
		this.button = sbutton.button;
		this.sLabelTexts = sLabelTexts;
		this.roleAreaCB = roleAreaCB;
		this.roleNameCB = roleNameCB;
		this.weaponClasCB = weaponClasCB;
		this.panel = panel;
		//色彩
				// Font, Color
				colors = new ColorUI().colors;
				 fonts = new FontUI().fonts;
		// 按键监听
		button.addActionListener(this);
	}

	/**
	 * 按键监听 - 进行String转Num，并计算
	 * 
	 * @param e
	 */
	private DrawLine drawLine_A = null;
	private DrawLine drawLine_B = null;
	public SLabel damageClass_1;
	public SLabel hitClass_1;
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == button) {
			// String转Num
			double[] dataNums = StringToNum.doWeapon_C(sLabelTexts); // 圣遗物数据
			// 角色、武器数据
			int roleAreaIndex, roleNameIndex, weaponClasIndex, weaponNameIndex;

			roleAreaIndex = roleAreaCB.comboBox.getSelectedIndex();
			System.out.println("获得Area按钮序号：" + roleAreaIndex);
			roleNameIndex = roleNameCB.comboBox.getSelectedIndex();
			System.out.println("获得Role按钮序号：" + roleNameIndex);
			Role role = new Role();
			double[] roleData = role.data(roleAreaIndex, roleNameIndex); // 角色数据
			//
			if (damageClass_1 != null){
				if(roleData[9] == 0){
					damageClass_1.label.setText("物伤");
				}else{
					damageClass_1.label.setText("法伤");
				}
			} else {
				if(roleData[9] == 0){
					damageClass_1 = new SLabel(panel, "物伤", 350, 20, 200, 30, colors[4], fonts[7]);
				}else{
					damageClass_1 = new SLabel(panel, "法伤", 350, 20, 200, 30, colors[4], fonts[7]);
				}
			}
			if (hitClass_1 != null){
				if(roleData[10] == 0){
					hitClass_1.label.setText("平A");
				}else if(roleData[10] == 1){
					hitClass_1.label.setText("重击");
				}else{
					hitClass_1.label.setText("下落");
				}
			} else {
				if(roleData[10] == 0){
					hitClass_1 = new SLabel(panel, "平A", 400, 20, 200, 30, colors[4], fonts[7]);
				}else if(roleData[10] == 1){
					hitClass_1 = new SLabel(panel, "重击", 400, 20, 200, 30, colors[4], fonts[7]);
				}else{
					hitClass_1 = new SLabel(panel, "下落", 400, 20, 200, 30, colors[4], fonts[7]);
				}
			}	


			//hitClass_1

			weaponClasIndex = weaponClasCB.comboBox.getSelectedIndex();

			Weapon weapon = new Weapon();
			//weaponNameIndex = 0;

			String[] weaponName = new dataIO().dataIO_Weapon(weaponClasIndex); // 武器名字

			// Base数据计算
			double[] Reference_1, Reference_2, Reference_3;
			Reference_1 = new double[weaponName.length];
			Reference_2 = new double[weaponName.length];
			Reference_3 = new double[weaponName.length];
			for (weaponNameIndex = 0; weaponNameIndex < weaponName.length; weaponNameIndex++) {
				double[] weaponData = weapon.data(weaponClasIndex, weaponNameIndex); // 武器数据
				double[] resultsOneWeapon = doCalWeapon_C(dataNums, roleData, weaponData, weaponName[weaponNameIndex]);
				Reference_1[weaponNameIndex] = resultsOneWeapon[0];
				Reference_2[weaponNameIndex] = resultsOneWeapon[1];
				Reference_3[weaponNameIndex] = resultsOneWeapon[2];
			}
			String[] weaponName_paint_A = new String[weaponName.length];
			String[] weaponName_paint_B = new String[weaponName.length];
			double[] weaponData_paint_A = new double[weaponName.length];
			double[] weaponData_paint_B = new double[weaponName.length];
			for(int i = 0; i<weaponName.length; i++){
				weaponName_paint_A[i] = weaponName[i];
				weaponName_paint_B[i] = weaponName[i];
				weaponData_paint_A[i] = Reference_1[i];
				weaponData_paint_B[i] = Reference_2[i];
			}
			System.out.println(weaponData_paint_A==weaponData_paint_B);

			// 绘制
			if (drawLine_A != null) {
				panel.remove(drawLine_A);
			}
			drawLine_A = new DrawLine(panel, 10, 50, 500, 700, weaponData_paint_A, weaponName_paint_A);

			// 绘制
			if (drawLine_B != null) {
				panel.remove(drawLine_B);
			}
			drawLine_B = new DrawLine(panel, 520, 50, 500, 700, weaponData_paint_B, weaponName_paint_B);
			System.out.println("监听执行");
		}
	}

	// public void sortPao(double[] dataA, String[] dataNameA) {

	// 	for (int i = 0; i < dataA.length - 1; i++) {
	// 		for (int j = 0; j < dataA.length - 1; j++) {
	// 			if (dataA[j] < dataA[j + 1]) {
	// 				double temp = dataA[j];
	// 				String tempS = dataNameA[j];
	// 				dataA[j] = dataA[j + 1];
	// 				dataNameA[j] = dataNameA[j + 1];
	// 				dataA[j + 1] = temp;
	// 				dataNameA[j + 1] = tempS;
	// 			}
	// 		}
	// 	}
	// 	sortDouble = dataA;
	// 	sortString = dataNameA;
	// }

	/**
	 * 单个武器，伤害计算
	 * 
	 * @param dataNum    - 0 套装攻击* ；1 套装暴击*；2套爆伤；3套物伤；4套元素增伤；
	 *                   5总生命；6总攻击；7总防御力；8总暴击率；9总爆伤；10总物伤；11总元素增伤；12平A加成；13重击加成；14下落攻击加成；15生命值加成
	 * @param roleData   // 0攻击加成// 1防御加成// 2生命加成// 3暴击率加成// 4爆伤加成// 5元素加成// 6物理加成
	 *                   // 7元素充能加成;// 8元素精通加成// 9平A属性 - 0 物理 - 1 元素// 10平A类型 - 0 平A
	 *                   - 1 重击 - 2 下落
	 * @param weaponData // 0精炼// 1攻击白字数值// 2主词条攻击加成// 3主词条防御加成//4主词条暴击率加成 //
	 *                   5主词条爆伤加成// 6主词条元素精通加// 7主词条物伤加成// 8主词条元素充能加成 // 9特效 -
	 *                   攻击加成// 10特效 - 防御加成// 11特效 - 暴击率加成// 12特效 - 爆伤加成// 13特效 -
	 *                   攻速加成 // 14特效 - 增伤 - 平A// 15特效 - 增伤 - 重击// 16特效 - 增伤 - 下落//
	 *                   17特效 - 增伤 - E技能 // 18特效 - 暴击率加成 - E技能专属// 19特效 - 增伤 - Q技能//
	 *                   20特效 - 增伤 - 物理伤害// 21特效 - 增伤 - 元素伤害 // 22特效 - 增伤 - 整体伤害//
	 *                   23特效 - 单独攻击 - 基于攻击力// 24特效 - 生命值加成// 25特效 - 生命值转化攻击力
	 * @param weaponName
	 * @return
	 */
	public static double[] doCalWeapon_C(double[] dataNum, double[] roleData, double[] weaponData, String weaponName) {
		double[] results = new double[3];
		// 攻击总值
		double attackAll;
		// 攻击白值
		double attackWhite;
		// 攻击绿值
		double attackGreen;
		// 总暴击率
		double critRate_A;
		double critRate_E;
		// 总爆伤
		double critDamage;
		// 总增伤
		double extraDamage_1 = 0.0; // 指标1：平A、重击、下落
		double extraDamage_2; // 指标2：E技能伤害
		double extraDamage_3; // 指标3：大招状态下、大招单段、大招爆发
		// 攻击%
		double attackMultiply;
		// 攻击+
		double attackAdd;
		// 突破方面
		double BTAttack = roleData[0]; // 攻击
		// double BTDefend = roleData[1]; // 防御
		double BTHealth = roleData[2]; // 生命
		double BTCritRate = roleData[3]; // 暴击率
		double BTCritDamage = roleData[4]; // 爆伤
		double BTExtraFireDamage = roleData[5]; // 元素增伤
		double BTExtraHitDamage = roleData[6]; // 物理增伤
		// double BTCharge = roleData[7]; // 充能效率
		// double BTMaster = roleData[8]; // 元素精通
		// 计算过程
		// 生命值计算
		double healthNum = 11000 + 11000 * (BTHealth + weaponData[24] + dataNum[15]) / 100 + dataNum[5];
		// 攻击白字计算
		attackWhite = 300 + weaponData[1]; // 默认自带2300攻击 + 武器白字攻击
		// 暴击率 & 暴击伤害
		critRate_A = 5 + BTCritRate + weaponData[4] + weaponData[11] + dataNum[1] + dataNum[8];// 突破暴击率 + 武器主词条暴击率 +
																								// 武器特性暴击率
		critRate_E = 5 + BTCritRate + weaponData[4] + weaponData[11] + dataNum[1] + dataNum[8] + weaponData[18];// +
																												// 圣遗物套装暴击率
																												// +
																												// 圣遗物小词条暴击率
		critDamage = 50 + BTCritDamage + weaponData[5] + dataNum[2] + dataNum[9];// 突破爆伤 + 武器主爆伤 + 圣遗物套爆伤 + 圣遗物小爆伤
		// 增伤
		if (roleData[9] == 0) { // 普通攻击为物理伤害
			if (roleData[10] == 0) { // 受攻速影响 - 是否平A
				extraDamage_1 = BTExtraHitDamage + weaponData[7] + weaponData[14] + weaponData[20] + weaponData[22]
						+ dataNum[3] + dataNum[10] + dataNum[12];// 突破物伤+武器主物伤+武器其他增伤+圣遗物
			} else if (roleData[10] == 1) { // 重击
				extraDamage_1 = BTExtraHitDamage + weaponData[7] + weaponData[15] + weaponData[20] + weaponData[22]
						+ dataNum[3] + dataNum[10] + dataNum[13];
			} else if (roleData[10] == 2) { // 下落
				extraDamage_1 = BTExtraHitDamage + weaponData[7] + weaponData[16] + weaponData[20] + weaponData[22]
						+ dataNum[3] + dataNum[10] + dataNum[14];
			}
		} else { // 普攻为元素伤害
			if (roleData[10] == 0) { // 受攻速影响 - 是否平A
				extraDamage_1 = BTExtraFireDamage + weaponData[14] + weaponData[21] + weaponData[22] + dataNum[4]
						+ dataNum[11] + dataNum[12];// 突破物伤+武器主物伤+武器其他增伤+圣遗物
			} else if (roleData[10] == 1) { // 重击
				extraDamage_1 = BTExtraFireDamage + weaponData[15] + weaponData[21] + weaponData[22] + dataNum[4]
						+ dataNum[11] + dataNum[13];
			} else if (roleData[10] == 2) { // 下落
				extraDamage_1 = BTExtraFireDamage + weaponData[16] + weaponData[21] + weaponData[22] + dataNum[4]
						+ dataNum[11] + dataNum[14];
			}
		}
		extraDamage_2 = BTExtraFireDamage + weaponData[17] + weaponData[21] + weaponData[22] + dataNum[4] + dataNum[11];
		extraDamage_3 = BTExtraFireDamage + weaponData[19] + weaponData[21] + weaponData[22] + dataNum[4] + dataNum[11];
		// 攻击%
		attackMultiply = (BTAttack + weaponData[2] + weaponData[9] + dataNum[0]);
		// 攻击+
		attackAdd = dataNum[6] + (weaponData[25] / 100 * healthNum);

		// 攻击面板计算
		attackGreen = attackWhite * attackMultiply / 100 + attackAdd;
		attackAll = attackWhite + attackGreen;

		// 伤害计算
		// 指标1：平A
		double base_A = (attackAll) * (1 + extraDamage_1 / 100);
		results[0] = base_A * (1 - critRate_A / 100) + base_A * (1 + critDamage / 100) * (critRate_A / 100);
		// 指标2：E
		double base_B = (attackAll) * (1 + extraDamage_2 / 100);
		results[1] = base_B * (1 - critRate_E / 100) + base_B * (1 + critDamage / 100) * (critRate_E / 100);
		// 指标3：Q
		double base_C = (attackAll) * (1 + extraDamage_3 / 100);
		results[2] = base_C * (1 - critRate_A / 100) + base_C * (1 + critDamage / 100) * (critRate_A / 100);

		// System.out.println("\n\n" + weaponName);
		// System.out.println("单次基础普工攻击" + base_A);
		// System.out.println("单次期望"+results[0]);
		// System.out.println("生命" + healthNum);
		// System.out.println("攻击白" + attackWhite);
		// System.out.println("攻击绿" + attackGreen);
		// System.out.println("总攻击" + attackAll);
		// System.out.println("增伤" + extraDamage_1);
		// System.out.println("爆伤" + critDamage);
		// System.out.println("暴击" + critRate_A);
		return results;
	}
}
