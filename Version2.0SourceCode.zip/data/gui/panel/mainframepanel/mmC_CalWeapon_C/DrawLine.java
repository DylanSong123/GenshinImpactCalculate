package data.gui.panel.mainframepanel.mmC_CalWeapon_C;

import javax.swing.JPanel;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;

import data.diy.color.ColorUI;
import data.diy.font.FontUI;

import java.awt.Canvas;
import java.awt.Graphics;

/**
 * DrawLine
 */
public class DrawLine extends Canvas {

	public double[] paintData;
	public double[] paintDataPercent;
	private double max;
	public String[] weaponName;
	// private int panelY;
	// private JPanel panel;
	private ColorUIResource[] colors;
	private FontUIResource[] fonts;


	// Canvas canvas = new Canvas();
	public DrawLine(JPanel panel, int x, int y, int width, int height, double[] paintData, String[] weaponName) {
		this.paintData = paintData;
		this.weaponName = weaponName;
		// this.panelY = y;
		// this.panel = panel;
		// Font, Color
		colors = new ColorUI().colors;
		fonts = new FontUI().fonts;
		// 画布设置
		System.out.println("Canvas");
		this.setBackground(colors[1]);
		this.setBounds(x, y, width, height);
		panel.add(this);
		this.setVisible(true);

		// System.out.println("排序前");
		// for (int i = 0; i < paintData.length; i++) {
		// 	System.out.println(i + " - per：" + paintData[i]);
		// 	System.out.println(i + " - Num：" + weaponName[i]);
		// }
 
		// 排序 - Reference_B
		double[] sortTemp_B = new double[weaponName.length];
		sortTemp_B = this.paintData;
		String[] nameTemp_B = new String[weaponName.length];
		nameTemp_B = weaponName;
		for (int i = 0; i < weaponName.length - 1; i++) {
			for (int j = 0; j < weaponName.length - 1; j++) {
				if (sortTemp_B[j] < sortTemp_B[j + 1]) {
					double temp = sortTemp_B[j];
					String tempS = nameTemp_B[j];
					sortTemp_B[j] = sortTemp_B[j + 1];
					nameTemp_B[j] = nameTemp_B[j + 1];
					sortTemp_B[j + 1] = temp;
					nameTemp_B[j + 1] = tempS;
				}
			}
		}
		this.paintData = sortTemp_B;
		weaponName = nameTemp_B;
		// 数据值域分析
		max = this.paintData[0];
		// max = maxORmin(paintData)[0];
		// min = maxORmin(paintData)[1];
		// 占比分析
		paintDataPercent = new double[this.paintData.length];
		for (int i = 0; i < this.paintData.length; i++) {
			paintDataPercent[i] = this.paintData[i] / max;
		}
		//
		// System.out.println("排序后");
		for (int i = 0; i < paintDataPercent.length; i++) {
			System.out.println(i + " - per：" + this.paintData[i]);
			System.out.println(i + " - Num：" + weaponName[i]);
		}
	}

	@Override
	public void paint(Graphics g) {
		// 绘图
		double baseLength = this.getWidth() / 5.0 * 2.0;
		double baseGapY = (this.getHeight() / (paintData.length - 1)) / 20.0 * 19.0;
		double baseHeight = baseGapY / 5.0 * 2.0;
		double sumY = -5.0;
		//
		// System.out.println("最后画图时刻，paintData长度：" + paintData.length + "，名字长度：" + weaponName.length + "，间隔距离：" + baseGapY);
		// System.out.println("间隔距离计算过程，获得高度：" + this.getHeight() + "，前边结果: " + (this.getHeight() / (paintData.length - 1)));
		//
		g.setColor(colors[2]); // 选颜色
		g.fillRect(260, (int) (sumY + baseGapY + baseHeight / 2), 1, (int) (baseGapY * (paintData.length - 1)));
		g.fillRect(this.getWidth() - 1, (int) (sumY + baseGapY + baseHeight / 2), 1,
				(int) (baseGapY * (paintData.length - 1)));
		for (int i = 0; i < paintData.length; i++) {
			g.setColor(colors[6]); // 选颜色
			g.fillRect(265, (int) (sumY += baseGapY), (int) (paintDataPercent[i] * baseLength), (int) (baseHeight)); // 条形图
			//
			g.setColor(colors[2]); // 选颜色
			g.fillRect(256, (int) (sumY + baseHeight / 2), 8, 1);// 坐标轴各个点位
			//
			g.setFont(fonts[18]);
			g.setColor(colors[3]); // 选颜色
			g.drawString(weaponName[i], 62, (int) (sumY + baseHeight / 2 + 5)); // 文字 - 武器名字
			//
			g.drawString(String.format("%.0f", paintData[i]), 2, (int) (sumY + baseHeight / 2 + 5)); // 文字 - 伤害数值

		}
	}

	public static double[] maxORmin(double[] data) {
		int length = data.length;
		double[] maxmin = new double[2];
		double min = 99999999999.9;
		double max = -10000000.0;
		for (int i = 0; i < length; i++) {
			if (data[i] > max) {
				max = data[i];
			}
			if (data[i] < min) {
				min = data[i];
			}
		}
		maxmin[0] = max;
		maxmin[1] = min;
		return maxmin;
	}
}