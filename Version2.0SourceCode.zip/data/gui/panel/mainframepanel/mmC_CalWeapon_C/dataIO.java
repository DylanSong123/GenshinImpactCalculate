package data.gui.panel.mainframepanel.mmC_CalWeapon_C;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * dataIO
 */

public class dataIO {

	private String[] strArrs_A;

	public String[] dataIO_Role_A() {
		// 角色数据载入
		String fileNameAString = "data/saves/database/RoleDatabase0.csv";// 蒙德
		// 第一次
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(fileNameAString);// 加载路径
			int fileBytesNum = fis.available();//
			byte[] fileBytes = new byte[fileBytesNum];// 搬运工
			fis.read(fileBytes); // 返回字节数量
			String fileBytesString = new String(fileBytes);// 创建字节数量大小的String
			String str = fileBytesString; // 继承
			strArrs_A = str.split("Num");// 分割
		} catch (FileNotFoundException throwe) {
			throwe.printStackTrace();
		} catch (IOException throwe) {
			throwe.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException throwe) {
					throwe.printStackTrace();
				}
			}
		}
		// 数据选择
		String[] RoleName_IO_A = new String[strArrs_A.length - 1];
		String[] strTheRole;
		for (int i = 1; i < strArrs_A.length; i++) {
			strTheRole = strArrs_A[i].split(",");
			RoleName_IO_A[i - 1] = strTheRole[1];// 名称
		}
		return RoleName_IO_A;
	}

	private String[] strArrs_B;

	public String[] dataIO_Role_B() {
		// 角色数据载入
		String fileNameBString = "data/saves/database/RoleDatabase1.csv";// 璃月
		// 第一次
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(fileNameBString);// 加载路径
			int fileBytesNum = fis.available();//
			byte[] fileBytes = new byte[fileBytesNum];// 搬运工
			fis.read(fileBytes); // 返回字节数量
			String fileBytesString = new String(fileBytes);// 创建字节数量大小的String
			String str = fileBytesString; // 继承
			strArrs_B = str.split("Num");// 分割
		} catch (FileNotFoundException throwe) {
			throwe.printStackTrace();
		} catch (IOException throwe) {
			throwe.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException throwe) {
					throwe.printStackTrace();
				}
			}
		}
		// 数据选择
		String[] RoleName_IO_B = new String[strArrs_B.length - 1];
		String[] strTheRole;
		for (int i = 1; i < strArrs_B.length; i++) {
			strTheRole = strArrs_B[i].split(",");
			RoleName_IO_B[i - 1] = strTheRole[1];// 名称
		}
		return RoleName_IO_B;
	}

	private String[] strArrs_C;

	public String[] dataIO_Role_C() {
		// 角色数据载入
		String fileNameCString = "data/saves/database/RoleDatabase2.csv";// 稻妻
		// 第一次
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(fileNameCString);// 加载路径
			int fileBytesNum = fis.available();//
			byte[] fileBytes = new byte[fileBytesNum];// 搬运工
			fis.read(fileBytes); // 返回字节数量
			String fileBytesString = new String(fileBytes);// 创建字节数量大小的String
			String str = fileBytesString; // 继承
			strArrs_C = str.split("Num");// 分割
		} catch (FileNotFoundException throwe) {
			throwe.printStackTrace();
		} catch (IOException throwe) {
			throwe.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException throwe) {
					throwe.printStackTrace();
				}
			}
		}
		// 数据选择
		String[] RoleName_IO_C = new String[strArrs_C.length - 1];
		String[] strTheRole;
		for (int i = 1; i < strArrs_C.length; i++) {
			strTheRole = strArrs_C[i].split(",");
			RoleName_IO_C[i - 1] = strTheRole[1];// 名称

		}
		return RoleName_IO_C;
	}

	private String[] strArrs_0;

	public String[] dataIO_Weapon(int indexNum) {
		String fileNameCString = null;
		switch (indexNum) {
			case 0:
				fileNameCString = "data/saves/database/WeaponDatabase0.csv";// 单手剑
				break;
			case 1:
				fileNameCString = "data/saves/database/WeaponDatabase1.csv";// 双手
				break;
			case 2:
				fileNameCString = "data/saves/database/WeaponDatabase2.csv";// 弓
				break;
			case 3:
				fileNameCString = "data/saves/database/WeaponDatabase3.csv";// 枪
				break;
			case 4:
				fileNameCString = "data/saves/database/WeaponDatabase4.csv";// 法器
				break;
			default:
				break;
		}
		// 角色数据载入

		// 第一次
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(fileNameCString);// 加载路径
			int fileBytesNum = fis.available();//
			byte[] fileBytes = new byte[fileBytesNum];// 搬运工
			fis.read(fileBytes); // 返回字节数量
			String fileBytesString = new String(fileBytes);// 创建字节数量大小的String
			String str = fileBytesString; // 继承
			strArrs_0 = str.split("Num");// 分割
		} catch (FileNotFoundException throwe) {
			throwe.printStackTrace();
		} catch (IOException throwe) {
			throwe.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException throwe) {
					throwe.printStackTrace();
				}
			}
		}
		// 数据选择
		String[] WeapinName_IO_0 = new String[strArrs_0.length - 1];
		String[] strTheRole;
		for (int i = 1; i < strArrs_0.length; i++) {
			strTheRole = strArrs_0[i].split(",");
			WeapinName_IO_0[i - 1] = strTheRole[1];// 名称

		}
		return WeapinName_IO_0;
	}

}
