package data.gui.panel.mainframepanel.mmB_CalPre_B;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import data.gui.standard.SButton;
import data.gui.standard.SLabel;
import data.gui.standard.SLabelText;
import data.gui.standard.SPanel;
import data.gui.standard.SRadioButton;
import data.main.StringToNum;

/**
 * CalBase_A - 基本计算器
 */
public class CalPre_B {
	public JPanel panelTop, panelA, panelB;

	public CalPre_B(JFrame frame, int x, int y, int width, int height, ColorUIResource[] colors,
			FontUIResource[] fonts) {
		// 双面板控制
		int gapX = width / 5 * 4;
		// 面板
		SPanel sPanelTop = new SPanel(frame, x, y, width + 5, 50, colors[1]);
		sPanelTop.panel.setLayout(null);
		this.panelTop = sPanelTop.panel;
		SPanel sPanelA = new SPanel(frame, x, y + 55, gapX, height, colors[1]);// 主面板
		sPanelA.panel.setLayout(null);
		this.panelA = sPanelA.panel;
		SPanel sPanelB = new SPanel(frame, x + gapX + 5, y + 55, width - gapX, height, colors[1]);// 次面板
		sPanelB.panel.setLayout(null);
		this.panelB = sPanelB.panel;
		// 控件
		SLabelText[] sLabelTexts = new SLabelText[50];
		SRadioButton[] sRadioButtons = new SRadioButton[3];
		// 主标题
		new SLabel(this.panelTop, "2：高级面板伤害计算器", 20, 10, 300, 30, colors[4], fonts[9]);
		int gapY = 35;
		// 分控件 - 左面板
		int sumX = 50;
		int sumY = -10;
		sLabelTexts[0] = new SLabelText(this.panelA, "角色等级", "90", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[1] = new SLabelText(this.panelA, "角色自带白字攻击", "323", sumX, sumY += gapY, 200, 30, 200, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		new SLabel(this.panelA, "角色突破加成类型", sumX, sumY += gapY + 15, 200, 30, colors[4], fonts[9]);
		sRadioButtons[0] = new SRadioButton(this.panelA, sumX + 200, sumY, 120, 30, 120, "攻击加成", "暴击率", "爆伤", "元素加伤",
				colors[4], colors[1], fonts[9]);
		sLabelTexts[2] = new SLabelText(this.panelA, "加成数值", "24", sumX + 100, sumY += gapY, 100, 30, 100, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[3] = new SLabelText(this.panelA, "技能倍率", "100", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);

		sLabelTexts[4] = new SLabelText(this.panelA, "武器攻击白值", "510", sumX, sumY += gapY + 15, 200, 30, 200, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[5] = new SLabelText(this.panelA, "武器攻击%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[6] = new SLabelText(this.panelA, "武器暴击%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[7] = new SLabelText(this.panelA, "武器爆伤%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[8] = new SLabelText(this.panelA, "武器增伤%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);

		new SLabel(this.panelA, "圣遗物套装", sumX, sumY += gapY + 15, 200, 30, colors[4], fonts[9]);
		sLabelTexts[9] = new SLabelText(this.panelA, "套装攻击加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[10] = new SLabelText(this.panelA, "套装暴击加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[11] = new SLabelText(this.panelA, "套装增伤加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);

		// 生之花
		new SLabel(this.panelA, "生之花", sumX, sumY += gapY + 15, 200, 30, colors[4], fonts[9]);
		sLabelTexts[12] = new SLabelText(this.panelA, "攻击+加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[13] = new SLabelText(this.panelA, "攻击%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[14] = new SLabelText(this.panelA, "暴击%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[15] = new SLabelText(this.panelA, "爆伤%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);

		sumY = 100;
		sumX = 450;
		// 死之羽
		new SLabel(this.panelA, "死之羽", sumX, sumY += gapY + 15, 200, 30, colors[4], fonts[9]);
		sLabelTexts[16] = new SLabelText(this.panelA, "攻击主词条", "311", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[17] = new SLabelText(this.panelA, "攻击+加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[18] = new SLabelText(this.panelA, "攻击%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[19] = new SLabelText(this.panelA, "暴击%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[20] = new SLabelText(this.panelA, "爆伤%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);

		// 时之沙
		new SLabel(this.panelA, "时之沙", sumX, sumY += gapY + 15, 200, 30, colors[4], fonts[9]);
		sLabelTexts[21] = new SLabelText(this.panelA, "攻击%加成", "46.6", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[22] = new SLabelText(this.panelA, "攻击+加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[23] = new SLabelText(this.panelA, "暴击%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[24] = new SLabelText(this.panelA, "爆伤%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		// 自定义加成
		new SLabel(this.panelA, "自定义加成", sumX, sumY += gapY + 15, 200, 30, colors[4], fonts[9]);
		sLabelTexts[46] = new SLabelText(this.panelA, "攻击%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[47] = new SLabelText(this.panelA, "暴击%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[48] = new SLabelText(this.panelA, "爆伤%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[49] = new SLabelText(this.panelA, "增伤%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);

		sumY = -10;
		sumX = 850;
		// 空之杯
		new SLabel(this.panelA, "空之杯", sumX, sumY += gapY, 200, 30, colors[4], fonts[9]);
		new SLabel(this.panelA, "空之杯类型", sumX, sumY += gapY, 200, 30, colors[4], fonts[9]);
		sRadioButtons[1] = new SRadioButton(this.panelA, sumX + 200, sumY, 120, 30, 120, "增伤杯", "攻击杯", colors[4],
				colors[1], fonts[9]);

		sLabelTexts[25] = new SLabelText(this.panelA, "主词条%加成", "46.6", sumX, sumY += gapY + 40, 200, 30, 200, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[26] = new SLabelText(this.panelA, "攻击+加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[27] = new SLabelText(this.panelA, "攻击%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[28] = new SLabelText(this.panelA, "暴击%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[29] = new SLabelText(this.panelA, "爆伤%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);

		// 理之冠
		new SLabel(this.panelA, "理之冠", sumX, sumY += gapY + 15, 200, 30, colors[4], fonts[9]);
		new SLabel(this.panelA, "理之冠类型", sumX, sumY += gapY, 200, 30, colors[4], fonts[9]);
		sRadioButtons[2] = new SRadioButton(this.panelA, sumX + 200, sumY, 120, 30, 120, "爆伤头", "暴击头", colors[4],
				colors[1], fonts[9]);
		sLabelTexts[30] = new SLabelText(this.panelA, "主词条%加成", "62.2", sumX, sumY += gapY + 40, 200, 30, 200, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[31] = new SLabelText(this.panelA, "攻击+加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[32] = new SLabelText(this.panelA, "攻击%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[33] = new SLabelText(this.panelA, "暴击%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[34] = new SLabelText(this.panelA, "爆伤%加成", "0", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		// 敌人属性
		new SLabel(this.panelA, "敌人属性", sumX, sumY += gapY + 15, 200, 30, colors[4], fonts[9]);
		sLabelTexts[43] = new SLabelText(this.panelA, "敌人等级", "90", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[44] = new SLabelText(this.panelA, "敌人抗性", "10", sumX, sumY += gapY, 200, 30, 200, 100, colors[4],
				colors[1], colors[4], fonts[9], fonts[9]);
		// 分控件 - 右面板
		sumX = 20;
		sumY = 250;
		sLabelTexts[35] = new SLabelText(this.panelB, "攻击总值", "0", sumX, sumY += gapY, 100, 30, 150, 100, colors[4],
				colors[4], colors[1], fonts[9], fonts[9], true);
		sLabelTexts[36] = new SLabelText(this.panelB, "攻击白值", "0", sumX, sumY += gapY, 100, 30, 150, 100, colors[4],
				colors[4], colors[1], fonts[9], fonts[9], true);
		sLabelTexts[37] = new SLabelText(this.panelB, "攻击绿值", "0", sumX, sumY += gapY, 100, 30, 150, 100, colors[4],
				colors[4], colors[1], fonts[9], fonts[9], true);
		sLabelTexts[38] = new SLabelText(this.panelB, "暴击率", "0", sumX, sumY += gapY, 100, 30, 150, 100, colors[4],
				colors[4], colors[1], fonts[9], fonts[9], true);
		sLabelTexts[39] = new SLabelText(this.panelB, "暴击伤害", "0", sumX, sumY += gapY, 100, 30, 150, 100, colors[4],
				colors[4], colors[1], fonts[9], fonts[9], true);
		sLabelTexts[45] = new SLabelText(this.panelB, "输出增伤", "0", sumX, sumY += gapY, 100, 30, 150, 100, colors[4],
				colors[4], colors[1], fonts[9], fonts[9], true);

		SLabelText onceBaseDamageLT = new SLabelText(this.panelB, "单次基础伤害", "0", sumX, sumY += gapY + 15, 150, 30, 150,
				120, colors[4], colors[4], colors[1], fonts[9], fonts[9], true);
		sLabelTexts[40] = onceBaseDamageLT;
		SLabelText onceCritDamageLT = new SLabelText(this.panelB, "单次暴击伤害", "0", sumX, sumY += gapY, 150, 30, 150, 120,
				colors[4], colors[4], colors[1], fonts[9], fonts[9], true);
		sLabelTexts[41] = onceCritDamageLT;
		SLabelText onceExpectDamageLT = new SLabelText(this.panelB, "单次期望伤害", "0", sumX, sumY += gapY, 150, 30, 150,
				120, colors[4], colors[4], colors[1], fonts[9], fonts[9], true);
		sLabelTexts[42] = onceExpectDamageLT;

		// 计算按钮
		SButton calButton = new SButton(this.panelB, "计算", 50, 650, 200, 100, colors[4], colors[3], fonts[11]);
		new CalButtonListen(calButton, sLabelTexts, sRadioButtons);
	}
}

/**
 * CalButtonListen - 计算按钮监听
 */
class CalButtonListen implements ActionListener {

	private JButton button;
	private SLabelText[] sLabelTexts;
	private SRadioButton[] sRadioButtons;

	/**
	 * 
	 * @param sbutton 计算按键
	 */
	public CalButtonListen(SButton sbutton, SLabelText[] sLabelTexts, SRadioButton[] sRadioButtons) {
		this.button = sbutton.button;
		this.sLabelTexts = sLabelTexts;
		this.sRadioButtons = sRadioButtons;
		// 按键监听
		button.addActionListener(this);
	}

	/**
	 * 按键监听 - 进行String转Num，并计算
	 * 
	 * @param e
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == button) {
			// String转Num
			double[] dataNums = StringToNum.doPre_B(sLabelTexts);
			// Base数据计算
			double[] results = doCalPre_B(dataNums, sRadioButtons);
			// 返回TextField
			sLabelTexts[40].textField.setText(" " + String.format("%.1f", results[0]));
			sLabelTexts[41].textField.setText(" " + String.format("%.1f", results[1]));
			sLabelTexts[42].textField.setText(" " + String.format("%.1f", results[2]));

			sLabelTexts[35].textField.setText(" " + String.format("%.1f", results[3]));
			sLabelTexts[36].textField.setText(" " + String.format("%.1f", results[4]));
			sLabelTexts[37].textField.setText(" " + String.format("%.1f", results[5]));
			sLabelTexts[38].textField.setText(" " + String.format("%.1f", results[6]));
			sLabelTexts[39].textField.setText(" " + String.format("%.1f", results[7]));
			sLabelTexts[45].textField.setText(" " + String.format("%.1f", results[8]));
		}
	}

	/**
	 * 伤害计算过程
	 * 
	 * @param dataNum       - double - 输入数据
	 * @param sRadioButtons - 单选项
	 * @return - double - 结果
	 */
	public static double[] doCalPre_B(double[] dataNum, SRadioButton[] sRadioButtons) {
		double[] results = new double[9];
		// 攻击总值
		double attackAll;
		// 攻击白值
		double attackWhite;
		// 攻击绿值
		double attackGreen;
		// 总暴击率
		double critRate;
		// 总爆伤
		double critDamage;
		// 总增伤
		double extraDamage;
		// 攻击%
		double attackMultiply;
		// 攻击+
		double attackAdd;
		// 突破方面
		double BTAttack = 0.0;
		double BTCritRate = 0.0;
		double BTCritDamage = 0.0;
		double BTExtraDamage = 0.0;
		// 抗性Negative resistance increases injury
		double resistNum = dataNum[44];
		double neResistAddDamage = 0.0;
		if(resistNum<0){
			neResistAddDamage = 0.5 * (-resistNum);
			dataNum[44] = 0.0;
		}
		// 计算过程
		if (sRadioButtons[0].radioButtonA.isSelected()) { // 突破加攻击
			BTAttack = dataNum[2];
		} else if (sRadioButtons[0].radioButtonB.isSelected()) { // 突破加暴击率
			BTCritRate = dataNum[2];
		} else if (sRadioButtons[0].radioButtonC.isSelected()) { // 突破加暴击伤害
			BTCritDamage = dataNum[2];
		} else if (sRadioButtons[0].radioButtonD.isSelected()) { // 突破加增伤
			BTExtraDamage = dataNum[2];
		}
		// 攻击白字计算
		attackWhite = dataNum[1] + dataNum[4];
		// 暴击率 & 暴击伤害
		if (sRadioButtons[2].radioButtonA.isSelected()) { // true - 爆伤头；false - 暴击头
			critRate = 5 + BTCritRate + dataNum[6] + dataNum[10] + dataNum[14] + dataNum[19] + dataNum[23] + dataNum[28]
					+ dataNum[33] + dataNum[47];
			critDamage = 50 + BTCritDamage + dataNum[7] + dataNum[15] + dataNum[20] + dataNum[24] + dataNum[29]
					+ dataNum[34] + dataNum[30] + dataNum[48];
		} else {
			critRate = 5 + BTCritRate + dataNum[6] + dataNum[10] + dataNum[14] + dataNum[19] + dataNum[23] + dataNum[28]
					+ dataNum[33] + dataNum[30] + dataNum[47];
			critDamage = 50 + BTCritDamage + dataNum[7] + dataNum[15] + dataNum[20] + dataNum[24] + dataNum[29]
					+ dataNum[34] + dataNum[48];
		}
		if (critRate > 100) { // 暴击率修正
			critRate = 100;
		}
		// 增伤 & 攻击%
		if (sRadioButtons[1].radioButtonA.isSelected()) { // true - 增伤杯；false - 攻击杯 + dataNum[]
			extraDamage = BTExtraDamage + dataNum[8] + dataNum[11] + dataNum[25] + dataNum[49] + neResistAddDamage;
			attackMultiply = BTAttack + dataNum[5] + dataNum[9] + dataNum[13] + dataNum[18] + dataNum[21] + dataNum[27]
					+ dataNum[32] + dataNum[46];
		} else {
			extraDamage = BTExtraDamage + dataNum[8] + dataNum[11] + dataNum[49] + neResistAddDamage;
			attackMultiply = BTAttack + dataNum[5] + dataNum[9] + dataNum[13] + dataNum[18] + dataNum[21] + dataNum[25]
					+ dataNum[27] + dataNum[32] + dataNum[46];
		}
		// 攻击+
		attackAdd = dataNum[12] + dataNum[16] + dataNum[17] + dataNum[22] + dataNum[26] + dataNum[31];

		// 攻击面板计算
		attackGreen = attackWhite * attackMultiply / 100 + attackAdd;
		attackAll = attackWhite + attackGreen;

		// 伤害计算
		results[0] = 0.5 * (attackAll) * (1 + extraDamage / 100) * (dataNum[3] / 100) * (1 - dataNum[44] / 100)
				* (1 + (dataNum[43] - dataNum[0]) * 0.002940);
		results[1] = results[0] * (1 + critDamage / 100);
		results[2] = results[0] * (1 - critRate / 100) + results[1] * critRate / 100;

		results[3] = attackAll;
		results[4] = attackWhite;
		results[5] = attackGreen;
		results[6] = critRate;
		results[7] = critDamage;
		results[8] = extraDamage;
		return results;
	}
}