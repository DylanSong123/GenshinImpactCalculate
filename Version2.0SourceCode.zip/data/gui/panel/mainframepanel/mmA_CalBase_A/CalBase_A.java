package data.gui.panel.mainframepanel.mmA_CalBase_A;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import data.gui.standard.SButton;
import data.gui.standard.SLabel;
import data.gui.standard.SLabelText;
import data.gui.standard.SPanel;
import data.main.StringToNum;

/**
 * CalBase_A - 基本计算器
 */
public class CalBase_A {
	public JPanel panelTop, panelA, panelB;

	public CalBase_A(JFrame frame, int x, int y, int width, int height, ColorUIResource[] colors,
			FontUIResource[] fonts) {
		// 双面板控制
		int gapX = width / 2;
		// 面板
		SPanel sPanelTop = new SPanel(frame, x, y, width + 5, 50, colors[1]);
		sPanelTop.panel.setLayout(null);
		this.panelTop = sPanelTop.panel;
		SPanel sPanelA = new SPanel(frame, x, y + 55, gapX, height, colors[1]);// 主面板
		sPanelA.panel.setLayout(null);
		this.panelA = sPanelA.panel;
		// SPanel sPanelB = new SPanel(frame, x + gapX + 5, y + 55, gapX, height,
		// colors[1]);// 次面板
		// sPanelB.panel.setLayout(null);
		// this.panelB = sPanelB.panel;
		// 控件
		SLabelText[] sLabelTexts = new SLabelText[12];
		// 主标题
		new SLabel(this.panelTop, "1：基本面板伤害计算器", 20, 10, 300, 30, colors[4], fonts[9]);

		// 分控件 - 左面板
		int sumY = -10;
		SLabelText yourLevelIntLT = new SLabelText(this.panelA, "角色等级", "90", 50, sumY += 50, 150, 30, 150, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[0] = yourLevelIntLT;
		SLabelText yourAttackWIntLT = new SLabelText(this.panelA, "攻击白值", "1000", 50, sumY += 50, 150, 30, 150, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[1] = yourAttackWIntLT;
		SLabelText yourAttackGIntLT = new SLabelText(this.panelA, "攻击绿值", "1000", 50, sumY += 50, 150, 30, 150, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[2] = yourAttackGIntLT;
		SLabelText yourCritRateLT = new SLabelText(this.panelA, "暴击率(%)", "50.0", 50, sumY += 50, 150, 30, 150, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[3] = yourCritRateLT;
		SLabelText yourCritDamageLT = new SLabelText(this.panelA, "暴击伤害(%)", "150.0", 50, sumY += 50, 150, 30, 150, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[4] = yourCritDamageLT;
		SLabelText yourExtraDamageLT = new SLabelText(this.panelA, "所有增伤(%)", "46.6", 50, sumY += 50, 150, 30, 150, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[5] = yourExtraDamageLT;
		SLabelText yourSkillRatioLT = new SLabelText(this.panelA, "技能倍率(%)", "100", 50, sumY += 50, 150, 30, 150, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[6] = yourSkillRatioLT;
		SLabelText enemyLevelIntLT = new SLabelText(this.panelA, "敌人等级", "90", 50, sumY += 80, 150, 30, 150, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[7] = enemyLevelIntLT;
		SLabelText enemyResistLT = new SLabelText(this.panelA, "敌人抗性(%)", "10", 50, sumY += 50, 150, 30, 150, 100,
				colors[4], colors[1], colors[4], fonts[9], fonts[9]);
		sLabelTexts[8] = enemyResistLT;
		// 分控件 - 右面板
		int sumX = 400;
		sumY = 150;
		SLabelText onceBaseDamageLT = new SLabelText(this.panelA, "单次基础伤害", " Null", sumX, sumY += 50, 150, 30, 150,
				120, colors[4], colors[4], colors[1], fonts[9], fonts[9], true);
		sLabelTexts[9] = onceBaseDamageLT;
		SLabelText onceCritDamageLT = new SLabelText(this.panelA, "单次暴击伤害", " Null", sumX, sumY += 50, 150, 30, 150,
				120, colors[4], colors[4], colors[1], fonts[9], fonts[9], true);
		sLabelTexts[10] = onceCritDamageLT;
		SLabelText onceExpectDamageLT = new SLabelText(this.panelA, "单次期望伤害", " Null", sumX, sumY += 50, 150, 30, 150,
				120, colors[4], colors[4], colors[1], fonts[9], fonts[9], true);
		sLabelTexts[11] = onceExpectDamageLT;
		// 计算按钮
		SButton calButton = new SButton(this.panelA, "计算", sumX + 50, 400, 200, 100, colors[4], colors[3], fonts[11]);
		new CalButtonListen(calButton, sLabelTexts);
	}
}

/**
 * CalButtonListen - 计算按钮监听
 */
class CalButtonListen implements ActionListener {

	private JButton button;
	private SLabelText[] sLabelTexts;

	/**
	 * 
	 * @param sbutton 计算按键
	 */
	public CalButtonListen(SButton sbutton, SLabelText[] sLabelTexts) {
		this.button = sbutton.button;
		this.sLabelTexts = sLabelTexts;
		// 按键监听
		button.addActionListener(this);
	}

	/**
	 * 按键监听 - 进行String转Num，并计算
	 * 
	 * @param e
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == button) {
			// String转Num
			double[] dataNums = StringToNum.doBase_A(sLabelTexts);
			// Base数据计算
			double[] results = doCalBase_A(dataNums);
			// 返回TextField
			sLabelTexts[9].textField.setText(" " + String.format("%.1f", results[0]));
			sLabelTexts[10].textField.setText(" " + String.format("%.1f", results[1]));
			sLabelTexts[11].textField.setText(" " + String.format("%.1f", results[2]));
		}
	}

	public static double[] doCalBase_A(double[] dataNum) {
		// 抗性Negative resistance increases injury
		double resistNum = dataNum[8];
		double neResistAddDamage = 0.0;
		if (resistNum < 0) {
			neResistAddDamage = 0.5 * (-resistNum);
			dataNum[8] = 0.0;
		}
		//暴击率100%控制
		if (dataNum[3] > 100) { // 暴击率修正
			dataNum[3] = 100;
		}

		double[] results = new double[3];
		results[0] = 0.5 * (dataNum[1] + dataNum[2]) * (1 + (dataNum[5]+neResistAddDamage) / 100) * (dataNum[6] / 100)
				* (1 - dataNum[8] / 100) * (1 + (dataNum[7] - dataNum[0]) * 0.002940);
		results[1] = results[0] * (1 + dataNum[4] / 100);
		results[2] = results[0] * (1 - dataNum[3] / 100) + results[1] * dataNum[3] / 100;
		return results;
	}
}