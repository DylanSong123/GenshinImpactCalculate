package data.diy.color;

import javax.swing.plaf.ColorUIResource;

public class ColorUI {
    public ColorUIResource[] colors = new ColorUIResource[10];
    private int theme = 0;
    public ColorUI(){
        switch (theme) {
            case 0:
                colors[0] = new ColorUIResource(10,10,10);//底板基础色
                colors[1] = new ColorUIResource(50,50,50);//标题颜色
                colors[2] = new ColorUIResource(100, 100, 100);//Test
                colors[3] = new ColorUIResource(150, 150, 150);//Title颜色1
				colors[4] = new ColorUIResource(200, 200, 200);//Title颜色1
				colors[5] = new ColorUIResource(250, 250, 250);//Title颜色1
				colors[6] = new ColorUIResource(200, 50, 50);//计算器3 - 条形图色彩
                break;
        
            default:
                break;
        }
    }
}
