package data.diy.font;

import javax.swing.plaf.FontUIResource;

public class FontUI {
    public FontUIResource[] fonts = new FontUIResource[21];
    public FontUI(){
        fonts[0] = new FontUIResource("Arial", FontUIResource.PLAIN, 15);
        fonts[1] = new FontUIResource("Arial", FontUIResource.PLAIN, 16);
        fonts[2] = new FontUIResource("Arial", FontUIResource.PLAIN, 17);
        fonts[3] = new FontUIResource("Arial", FontUIResource.PLAIN, 18);
        fonts[4] = new FontUIResource("Arial", FontUIResource.PLAIN, 19);
        fonts[5] = new FontUIResource("Arial", FontUIResource.PLAIN, 20);

        fonts[6] = new FontUIResource("黑体", FontUIResource.PLAIN, 16);
        fonts[7] = new FontUIResource("黑体", FontUIResource.PLAIN, 18);
        fonts[8] = new FontUIResource("黑体", FontUIResource.PLAIN, 20);
        fonts[9] = new FontUIResource("黑体", FontUIResource.PLAIN, 22);
        fonts[10] = new FontUIResource("黑体", FontUIResource.PLAIN, 24);
        fonts[11] = new FontUIResource("黑体", FontUIResource.PLAIN, 36);
        fonts[12] = new FontUIResource("黑体", FontUIResource.PLAIN, 64);
        fonts[13] = new FontUIResource("黑体", FontUIResource.PLAIN, 81);

        fonts[14] = new FontUIResource("黑体", FontUIResource.BOLD, 16); 
        fonts[15] = new FontUIResource("黑体", FontUIResource.BOLD, 18); 
        fonts[16] = new FontUIResource("黑体", FontUIResource.BOLD, 20);
        fonts[17] = new FontUIResource("黑体", FontUIResource.BOLD, 24);

		fonts[18] = new FontUIResource("宋体", FontUIResource.BOLD, 16);
		fonts[19] = new FontUIResource("宋体", FontUIResource.BOLD, 18);
		fonts[20] = new FontUIResource("宋体", FontUIResource.BOLD, 20);
    }
}
