package calculate;
public class LevelCorrectionClass {
    public double levelCorrectionClassMain(Double yourLevel,Double enemyLevel){
        double levelGapRate = 0.002942;
        double yourLevelNum = yourLevel;
        double enemyLevelNum = enemyLevel;
        double levelGapNum = yourLevelNum - enemyLevelNum;
        double levelCorrection = (1 + levelGapNum * levelGapRate);
        return levelCorrection;
    }
}
