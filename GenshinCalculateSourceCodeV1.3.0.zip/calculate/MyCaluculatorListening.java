package calculate;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
public class MyCaluculatorListening implements ActionListener {
    private JTextField yourLevel, skillRatios, yourCharactersBreakthrough_AttackRate, yourCharactersBreakthrough_CriticalRate, yourCharactersBreakthrough_CriticalDamageRate, weaponWhite, weaponFeature_AttackRate, weaponFeature_CriticalRate, weaponFeature_CriticalDamageRate, weaponFeature_ExtraDamage, enemyLevel, enemyResistance, halidom_Main_AttackRate, halidom_Main_CriticalRate, halidom_Main_ExtraDamage, halidomFlower_mini_AttackGreen, halidomFlower_mini_AttackRate, halidomFlower_mini_CriticalRate, halidomFlower_mini_CriticalDamageRate, halidomFeather_AttackGreen, halidomFeather_mini_AttackGreen, halidomFeather_mini_AttackRate, halidomFeather_mini_CriticalRate, halidomFeather_mini_CriticalDamageRate, halidomHourglass_AttackRate, halidomHourglass_mini_AttackGreen, halidomHourglass_mini_AttackRate, halidomHourglass_mini_CriticalRate, halidomHourglass_mini_CriticalDamageRate, halidomCup_AttackRate, halidomCup_ExtraDamage, halidomCup_mini_AttackGreen, halidomCup_mini_AttackRate, halidomCup_mini_CriticalRate, halidomCup_mini_CriticalDamageRate, halidomCrown_CriticalRate, halidomCrown_CriticalDamageRate, halidomCrown_mini_AttackGreen, halidomCrown_mini_AttackRate, halidomCrown_mini_CriticalRate, halidomCrown_mini_CriticalDamageRate;
    private JTextField onceStrikeDamage, yourBaseWhite,onceCriticalStrikeDamage,singleExpectedDamage,attackWhite,attackGreen,criticalRate,criticalDamageRate;
    private JTextField theConsoles,extraNegativeResistance;
    public MyCaluculatorListening(JTextField yourLevel, JTextField skillRatios, JTextField yourBaseWhite, JTextField yourCharactersBreakthrough_AttackRate, JTextField yourCharactersBreakthrough_CriticalRate, JTextField yourCharactersBreakthrough_CriticalDamageRate, JTextField weaponWhite, JTextField weaponFeature_AttackRate, JTextField weaponFeature_CriticalRate, JTextField weaponFeature_CriticalDamageRate, JTextField weaponFeature_ExtraDamage, JTextField enemyLevel, JTextField enemyResistance, JTextField halidom_Main_AttackRate, JTextField halidom_Main_CriticalRate, JTextField halidom_Main_ExtraDamage, JTextField halidomFlower_mini_AttackGreen, JTextField halidomFlower_mini_AttackRate, JTextField halidomFlower_mini_CriticalRate, JTextField halidomFlower_mini_CriticalDamageRate, JTextField halidomFeather_AttackGreen, JTextField halidomFeather_mini_AttackGreen, JTextField halidomFeather_mini_AttackRate, JTextField halidomFeather_mini_CriticalRate, JTextField halidomFeather_mini_CriticalDamageRate, JTextField halidomHourglass_AttackRate, JTextField halidomHourglass_mini_AttackGreen, JTextField halidomHourglass_mini_AttackRate, JTextField halidomHourglass_mini_CriticalRate, JTextField halidomHourglass_mini_CriticalDamageRate, JTextField halidomCup_AttackRate, JTextField halidomCup_ExtraDamage, JTextField halidomCup_mini_AttackGreen, JTextField halidomCup_mini_AttackRate, JTextField halidomCup_mini_CriticalRate, JTextField halidomCup_mini_CriticalDamageRate, JTextField halidomCrown_CriticalRate, JTextField halidomCrown_CriticalDamageRate, JTextField halidomCrown_mini_AttackGreen, JTextField halidomCrown_mini_AttackRate, JTextField halidomCrown_mini_CriticalRate, JTextField halidomCrown_mini_CriticalDamageRate,JTextField onceStrikeDamage,JTextField onceCriticalStrikeDamage,JTextField singleExpectedDamage,JTextField attackWhite,JTextField attackGreen,JTextField criticalRate,JTextField criticalDamageRate,JTextField theConsoles,JTextField extraNegativeResistance){
        //塞入
        this.yourLevel = yourLevel;
        this.skillRatios = skillRatios;
        this.yourBaseWhite = yourBaseWhite;
        this.yourCharactersBreakthrough_AttackRate = yourCharactersBreakthrough_AttackRate;
        this.yourCharactersBreakthrough_CriticalRate = yourCharactersBreakthrough_CriticalRate;
        this.yourCharactersBreakthrough_CriticalDamageRate = yourCharactersBreakthrough_CriticalDamageRate;
        this.weaponWhite = weaponWhite;
        this.weaponFeature_AttackRate = weaponFeature_AttackRate;
        this.weaponFeature_CriticalRate = weaponFeature_CriticalRate;
        this.weaponFeature_CriticalDamageRate = weaponFeature_CriticalDamageRate;
        this.weaponFeature_ExtraDamage = weaponFeature_ExtraDamage;
        this.enemyLevel = enemyLevel;
        this.enemyResistance = enemyResistance;
        this.halidom_Main_AttackRate = halidom_Main_AttackRate;
        this.halidom_Main_CriticalRate = halidom_Main_CriticalRate;
        this.halidom_Main_ExtraDamage = halidom_Main_ExtraDamage;
        this.halidomFlower_mini_AttackGreen = halidomFlower_mini_AttackGreen;
        this.halidomFlower_mini_AttackRate = halidomFlower_mini_AttackRate;
        this.halidomFlower_mini_CriticalRate = halidomFlower_mini_CriticalRate;
        this.halidomFlower_mini_CriticalDamageRate = halidomFlower_mini_CriticalDamageRate;
        this.halidomFeather_AttackGreen = halidomFeather_AttackGreen;
        this.halidomFeather_mini_AttackGreen = halidomFeather_mini_AttackGreen;
        this.halidomFeather_mini_AttackRate = halidomFeather_mini_AttackRate;
        this.halidomFeather_mini_CriticalRate = halidomFeather_mini_CriticalRate;
        this.halidomFeather_mini_CriticalDamageRate = halidomFeather_mini_CriticalDamageRate;
        this.halidomHourglass_AttackRate = halidomHourglass_AttackRate;
        this.halidomHourglass_mini_AttackGreen = halidomHourglass_mini_AttackGreen;
        this.halidomHourglass_mini_AttackRate = halidomHourglass_mini_AttackRate;
        this.halidomHourglass_mini_CriticalRate = halidomHourglass_mini_CriticalRate;
        this.halidomHourglass_mini_CriticalDamageRate = halidomHourglass_mini_CriticalDamageRate;
        this.halidomCup_AttackRate = halidomCup_AttackRate;
        this.halidomCup_ExtraDamage = halidomCup_ExtraDamage;
        this.halidomCup_mini_AttackGreen = halidomCup_mini_AttackGreen;
        this.halidomCup_mini_AttackRate = halidomCup_mini_AttackRate;
        this.halidomCup_mini_CriticalRate = halidomCup_mini_CriticalRate;
        this.halidomCup_mini_CriticalDamageRate = halidomCup_mini_CriticalDamageRate;
        this.halidomCrown_CriticalRate = halidomCrown_CriticalRate;
        this.halidomCrown_CriticalDamageRate = halidomCrown_CriticalDamageRate;
        this.halidomCrown_mini_AttackGreen = halidomCrown_mini_AttackGreen;
        this.halidomCrown_mini_AttackRate = halidomCrown_mini_AttackRate;
        this.halidomCrown_mini_CriticalRate = halidomCrown_mini_CriticalRate;
        this.halidomCrown_mini_CriticalDamageRate = halidomCrown_mini_CriticalDamageRate;
        this.onceStrikeDamage = onceStrikeDamage;
        this.onceCriticalStrikeDamage = onceCriticalStrikeDamage;
        this.singleExpectedDamage = singleExpectedDamage;
        this.attackWhite = attackWhite;
        this.attackGreen = attackGreen;
        this.criticalRate = criticalRate;
        this.criticalDamageRate = criticalDamageRate;
        this.theConsoles = theConsoles;
        this.extraNegativeResistance = extraNegativeResistance;
    }
    public void actionPerformed(ActionEvent e){
        //获取JTextField的内容
        double yourLevel = Double.parseDouble(this.yourLevel.getText());
        double skillRatios = (Double.parseDouble(this.skillRatios.getText())  /100);
        double yourBaseWhite = Double.parseDouble(this.yourBaseWhite.getText());
        double yourCharactersBreakthrough_AttackRate = (Double.parseDouble(this.yourCharactersBreakthrough_AttackRate.getText())  /100);
        double yourCharactersBreakthrough_CriticalRate = (Double.parseDouble(this.yourCharactersBreakthrough_CriticalRate.getText())  /100);
        double yourCharactersBreakthrough_CriticalDamageRate = (Double.parseDouble(this.yourCharactersBreakthrough_CriticalDamageRate.getText())  /100);
        double weaponWhite = Double.parseDouble(this.weaponWhite.getText());
        double weaponFeature_AttackRate = (Double.parseDouble(this.weaponFeature_AttackRate.getText())  /100);
        double weaponFeature_CriticalRate = (Double.parseDouble(this.weaponFeature_CriticalRate.getText())  /100);
        double weaponFeature_CriticalDamageRate = (Double.parseDouble(this.weaponFeature_CriticalDamageRate.getText())  /100);
        double weaponFeature_ExtraDamage = (Double.parseDouble(this.weaponFeature_ExtraDamage.getText())  /100);
        double enemyLevel = Double.parseDouble(this.enemyLevel.getText());
        double enemyResistance = (Double.parseDouble(this.enemyResistance.getText())  /100);
        double halidom_Main_AttackRate = (Double.parseDouble(this.halidom_Main_AttackRate.getText())  /100);
        //System.out.println("圣遗物攻击百分比加成："+halidom_Main_AttackRate);
        double halidom_Main_CriticalRate = (Double.parseDouble(this.halidom_Main_CriticalRate.getText())  /100);
        double halidom_Main_ExtraDamage = (Double.parseDouble(this.halidom_Main_ExtraDamage.getText())  /100);
        double halidomFlower_mini_AttackGreen = Double.parseDouble(this.halidomFlower_mini_AttackGreen.getText());
        double halidomFlower_mini_AttackRate = (Double.parseDouble(this.halidomFlower_mini_AttackRate.getText())  /100);
        double halidomFlower_mini_CriticalRate = (Double.parseDouble(this.halidomFlower_mini_CriticalRate.getText())  /100);
        double halidomFlower_mini_CriticalDamageRate = (Double.parseDouble(this.halidomFlower_mini_CriticalDamageRate.getText())  /100);
        double halidomFeather_AttackGreen = Double.parseDouble(this.halidomFeather_AttackGreen.getText());
        double halidomFeather_mini_AttackGreen = Double.parseDouble(this.halidomFeather_mini_AttackGreen.getText());
        double halidomFeather_mini_AttackRate = (Double.parseDouble(this.halidomFeather_mini_AttackRate.getText())  /100);
        double halidomFeather_mini_CriticalRate = (Double.parseDouble(this.halidomFeather_mini_CriticalRate.getText())  /100);
        double halidomFeather_mini_CriticalDamageRate = (Double.parseDouble(this.halidomFeather_mini_CriticalDamageRate.getText())  /100);
        double halidomHourglass_AttackRate = (Double.parseDouble(this.halidomHourglass_AttackRate.getText())  /100);
        double halidomHourglass_mini_AttackGreen = Double.parseDouble(this.halidomHourglass_mini_AttackGreen.getText());
        double halidomHourglass_mini_AttackRate = (Double.parseDouble(this.halidomHourglass_mini_AttackRate.getText())  /100);
        double halidomHourglass_mini_CriticalRate = (Double.parseDouble(this.halidomHourglass_mini_CriticalRate.getText())  /100);
        double halidomHourglass_mini_CriticalDamageRate = (Double.parseDouble(this.halidomHourglass_mini_CriticalDamageRate.getText())  /100);
        double halidomCup_AttackRate = (Double.parseDouble(this.halidomCup_AttackRate.getText())  /100);
        double halidomCup_ExtraDamage = (Double.parseDouble(this.halidomCup_ExtraDamage.getText())  /100);
        //System.out.println("理之冠增伤百分比加成："+halidomCup_ExtraDamage);
        double halidomCup_mini_AttackGreen = Double.parseDouble(this.halidomCup_mini_AttackGreen.getText());
        double halidomCup_mini_AttackRate = (Double.parseDouble(this.halidomCup_mini_AttackRate.getText())  /100);
        double halidomCup_mini_CriticalRate = (Double.parseDouble(this.halidomCup_mini_CriticalRate.getText())  /100);
        double halidomCup_mini_CriticalDamageRate = (Double.parseDouble(this.halidomCup_mini_CriticalDamageRate.getText())  /100);
        double halidomCrown_CriticalRate = (Double.parseDouble(this.halidomCrown_CriticalRate.getText())  /100);
        double halidomCrown_CriticalDamageRate = (Double.parseDouble(this.halidomCrown_CriticalDamageRate.getText())  /100);
        double halidomCrown_mini_AttackGreen = Double.parseDouble(this.halidomCrown_mini_AttackGreen.getText());
        double halidomCrown_mini_AttackRate = (Double.parseDouble(this.halidomCrown_mini_AttackRate.getText())  /100);
        double halidomCrown_mini_CriticalRate = (Double.parseDouble(this.halidomCrown_mini_CriticalRate.getText())  /100);
        double halidomCrown_mini_CriticalDamageRate = (Double.parseDouble(this.halidomCrown_mini_CriticalDamageRate.getText())  /100);
        double extraNegativeResistance = (Double.parseDouble(this.extraNegativeResistance.getText())  /100);
        // Main-计算-等级修正系数
        LevelCorrectionClass levelCorrectionClass = new LevelCorrectionClass();
        double levelCorrection = levelCorrectionClass.levelCorrectionClassMain(yourLevel, enemyLevel);
        //System.out.println("等级修正："+levelCorrection);
        // Main-计算--攻击白字计算-allAttackWhite
        AllAttackWhiteClass allAttackWhiteClass = new AllAttackWhiteClass();
        double allAttackWhite = allAttackWhiteClass.allAttackWhite(weaponWhite, yourBaseWhite);
        //System.out.println("白字："+allAttackWhite);
        // Main-计算-圣遗物攻击＋allHalidomAttackPlus
        AllHalidomAttackPlusClass allHalidomAttackPlusClass = new AllHalidomAttackPlusClass();
        double allHalidomAttackPlus = allHalidomAttackPlusClass.allHalidomAttackPlus(halidomFlower_mini_AttackGreen, halidomFeather_mini_AttackGreen, halidomFeather_AttackGreen, halidomHourglass_mini_AttackGreen, halidomCup_mini_AttackGreen, halidomCrown_mini_AttackGreen);
        //System.out.println("圣遗物攻击+："+allHalidomAttackPlus);
        // Main-计算-圣遗物攻击百分比加成-allHalidomAttackRate
        AllHalidomAttackRateClass allHalidomAttackRateClass = new AllHalidomAttackRateClass();
        double allHalidomAttackRate = allHalidomAttackRateClass.allHalidomAttackRateMain(halidom_Main_AttackRate, halidomFeather_mini_AttackRate, halidomHourglass_mini_AttackRate, halidomCup_mini_AttackRate, halidomCrown_mini_AttackRate, halidomHourglass_AttackRate,halidomCup_AttackRate, halidomFlower_mini_AttackRate);
        //System.out.println("圣遗物攻击百分比加成："+allHalidomAttackRate);
        // Main-计算-攻击绿字计算-allAttackGreen
        AllAttackGreenClass allAttackGreenClass = new AllAttackGreenClass();
        double allAttackGreen = allAttackGreenClass.allAttackGreenMain(allAttackWhite, yourCharactersBreakthrough_AttackRate, weaponFeature_AttackRate, allHalidomAttackRate, allHalidomAttackPlus);
        //System.out.println("攻击绿字加成"+allAttackGreen);
        // Main-计算-增伤计算-allExtraDamage
        AllExtraDamageClass allExtraDamageClass = new AllExtraDamageClass();
        double allExtraDamage = allExtraDamageClass.allExtraDamageMain(weaponFeature_ExtraDamage, halidom_Main_ExtraDamage, halidomCup_ExtraDamage, extraNegativeResistance);
        //System.out.println("增伤："+allExtraDamage);
        // Main-计算-暴击计算-allCriticalRate
        AllCriticalRateClass allCriticalRateClass = new AllCriticalRateClass();
        double allCriticalRate = allCriticalRateClass.allCriticalRateMain(yourCharactersBreakthrough_CriticalRate, weaponFeature_CriticalRate, halidom_Main_CriticalRate, halidomFlower_mini_CriticalRate, halidomFeather_mini_CriticalRate, halidomHourglass_mini_CriticalRate, halidomCup_mini_CriticalRate, halidomCrown_mini_CriticalRate, halidomCrown_CriticalRate);
        //System.out.println("暴击率："+allCriticalRate);
        // Main-计算-爆伤计算-allCriticalDamageRate
        AllCriticalDamageRateClass allCriticalDamageRateClass = new AllCriticalDamageRateClass();
        double allCriticalDamageRate = allCriticalDamageRateClass.allCriticalDamageRate(yourCharactersBreakthrough_CriticalDamageRate, weaponFeature_CriticalDamageRate, halidomCrown_CriticalDamageRate, halidomFlower_mini_CriticalDamageRate, halidomFeather_mini_CriticalDamageRate, halidomHourglass_mini_CriticalDamageRate, halidomCup_mini_CriticalDamageRate, halidomCrown_mini_CriticalDamageRate);
        //System.out.println("爆伤："+allCriticalDamageRate);
        //单次基础伤害、暴击伤害、期望伤害计算
        double onceDamage = (allAttackWhite + allAttackGreen) * (0.5 - 0.5 * enemyResistance) * (1+allExtraDamage) * skillRatios * levelCorrection;
        double onceCriticalDamage=onceDamage*(1+allCriticalDamageRate);
        double singleExpectedDamage=(1-allCriticalRate)*onceDamage+allCriticalRate*onceCriticalDamage;
// =====================================================================================================
        //返回setText
        this.attackWhite.setText(String.format("%.1f", allAttackWhite));
        this.attackGreen.setText(String.format("%.1f", allAttackGreen));
        this.criticalRate.setText(String.format("%.1f", (allCriticalRate*100)));
        this.criticalDamageRate.setText(String.format("%.1f", (allCriticalDamageRate*100)));
        this.onceStrikeDamage.setText(String.format("%.1f", onceDamage));
        this.onceCriticalStrikeDamage.setText(String.format("%.1f", onceCriticalDamage));
        this.singleExpectedDamage.setText(String.format("%.1f", singleExpectedDamage)); 
        this.theConsoles.setText("完成计算，请再次输入！");
        //控制台控制Text
        //称赞
        if( halidomFlower_mini_CriticalDamageRate>0.3 || halidomFeather_mini_CriticalDamageRate>0.3 || halidomHourglass_mini_CriticalDamageRate>0.3 || halidomCup_mini_CriticalDamageRate>0.3 || halidomCrown_mini_CriticalDamageRate>0.3)   this.theConsoles.setText("计算完了！好家伙，圣遗物xmsl~");
        if( halidomFlower_mini_CriticalRate>0.15 || halidomFeather_mini_CriticalRate>0.15 || halidomHourglass_mini_CriticalRate>0.15 || halidomCup_mini_CriticalRate>0.15 || halidomCrown_mini_CriticalRate>0.15)   this.theConsoles.setText("计算完了！好家伙，圣遗物xmsl~");
        //警告
        if( yourLevel<1 || yourLevel>90 )   this.theConsoles.setText("警告：等级超出1~90范围！");
        if( enemyResistance<0 || enemyResistance>1 )   this.theConsoles.setText("警告：抗性超出范围(看左边提示)！");
        if( halidomFeather_AttackGreen<0 || halidomFeather_AttackGreen>311 )   this.theConsoles.setText("警告：死之羽主词条超出0~311范围！");
        if( halidomHourglass_AttackRate<0 || halidomHourglass_AttackRate>0.466 )   this.theConsoles.setText("警告：时之沙主词条超出0~46.6范围！");
        if( halidomCup_AttackRate<0 || halidomCup_AttackRate>0.466 )   this.theConsoles.setText("警告：空之杯主词条超出0~46.6范围！");
        if( halidomCup_ExtraDamage<0 || halidomCup_ExtraDamage>0.466 )   this.theConsoles.setText("警告：空之杯主词条超出0~46.6范围！");
        if( halidomCrown_CriticalRate<0 || halidomCrown_CriticalRate>0.311 )   this.theConsoles.setText("警告：空之杯主词条超出0~31.1范围！");
        if( halidomCrown_CriticalDamageRate<0 || halidomCrown_CriticalDamageRate>0.622 )   this.theConsoles.setText("警告：空之杯主词条超出0~62.2范围！");
        //保存历史记录-HistoryRecord
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream("calculate\\HistoryRecord",false);     
            String firstRecord = yourLevel+","+(skillRatios*100)+","+yourBaseWhite+","+(yourCharactersBreakthrough_AttackRate*100)+","+(yourCharactersBreakthrough_CriticalRate*100)+","+(yourCharactersBreakthrough_CriticalDamageRate*100)+",";
            String secondRecord = weaponWhite+","+(weaponFeature_AttackRate*100)+","+(weaponFeature_CriticalRate*100)+","+(weaponFeature_CriticalDamageRate*100)+","+(weaponFeature_ExtraDamage*100)+",";
            String thirdRecord = enemyLevel+","+(enemyResistance*100)+","+(halidom_Main_AttackRate*100)+","+(halidom_Main_CriticalRate*100)+","+(halidom_Main_ExtraDamage*100)+",";
            String forthRecord = halidomFlower_mini_AttackGreen+","+(halidomFlower_mini_AttackRate*100)+","+(halidomFlower_mini_CriticalRate*100)+","+(halidomFlower_mini_CriticalDamageRate*100)+",";
            String fiveRecord = halidomFeather_AttackGreen+","+halidomFeather_mini_AttackGreen+","+(halidomFeather_mini_AttackRate*100)+","+(halidomFeather_mini_CriticalRate*100)+","+(halidomFeather_mini_CriticalDamageRate*100)+",";
            String sixthRecord = (halidomHourglass_AttackRate*100)+","+halidomHourglass_mini_AttackGreen+","+(halidomHourglass_mini_AttackRate*100)+","+(halidomHourglass_mini_CriticalRate*100)+","+(halidomHourglass_mini_CriticalDamageRate*100)+",";
            String seventhRecord = (halidomCup_AttackRate*100)+","+(halidomCup_ExtraDamage*100)+","+halidomCup_mini_AttackGreen+","+(halidomCup_mini_AttackRate*100)+","+(halidomCup_mini_CriticalRate*100)+","+(halidomCup_mini_CriticalDamageRate*100)+",";
            String eighthRecord = (halidomCrown_CriticalRate*100)+","+(halidomCrown_CriticalDamageRate*100)+","+halidomCrown_mini_AttackGreen+","+(halidomCrown_mini_AttackRate*100)+","+(halidomCrown_mini_CriticalRate*100)+","+(halidomCrown_mini_CriticalDamageRate*100)+",";
            String nightRecord = (extraNegativeResistance*100)+",";
            String allRecord = firstRecord+secondRecord+thirdRecord+forthRecord+fiveRecord+sixthRecord+seventhRecord+eighthRecord+nightRecord;
            byte[] sBytes = allRecord.getBytes();       //字符串转换成ascii字节数组
            fos.write(sBytes);   //
            fos.flush();
        } catch (FileNotFoundException throwe) {
            throwe.printStackTrace();
        } catch (IOException throwe) {
            throwe.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException throwe) {
                    throwe.printStackTrace();
                }
            }
        }
    }
}
