package calculate;

public class AllCriticalRateClass {
    public double allCriticalRateMain(double yourCharactersBreakthrough_CriticalRate ,
    double weaponFeature_CriticalRate ,double halidom_Main_CriticalRate ,
    double halidomFlower_mini_CriticalRate,double halidomFeather_mini_CriticalRate ,
    double halidomHourglass_mini_CriticalRate ,double halidomCup_mini_CriticalRate , 
    double halidomCrown_mini_CriticalRate , double halidomCrown_CriticalRate){
        double allCriticalRate = 0.05 + yourCharactersBreakthrough_CriticalRate +
        weaponFeature_CriticalRate + halidom_Main_CriticalRate +
        halidomFlower_mini_CriticalRate + halidomFeather_mini_CriticalRate +
        halidomHourglass_mini_CriticalRate + halidomCup_mini_CriticalRate + 
        halidomCrown_mini_CriticalRate + halidomCrown_CriticalRate;
        return allCriticalRate;
    }
}
