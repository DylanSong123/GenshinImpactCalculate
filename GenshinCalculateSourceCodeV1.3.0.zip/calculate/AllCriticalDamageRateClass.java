package calculate;

public class AllCriticalDamageRateClass {
    public double allCriticalDamageRate(double yourCharactersBreakthrough_CriticalDamageRate,
    double weaponFeature_CriticalDamageRate, double halidomCrown_CriticalDamageRate,
    double halidomFlower_mini_CriticalDamageRate,double  halidomFeather_mini_CriticalDamageRate,
    double halidomHourglass_mini_CriticalDamageRate,double  halidomCup_mini_CriticalDamageRate, 
    double halidomCrown_mini_CriticalDamageRate){

        double allCriticalDamageRate = 0.5 + yourCharactersBreakthrough_CriticalDamageRate +
        weaponFeature_CriticalDamageRate + halidomCrown_CriticalDamageRate +
        halidomFlower_mini_CriticalDamageRate + halidomFeather_mini_CriticalDamageRate +
        halidomHourglass_mini_CriticalDamageRate + halidomCup_mini_CriticalDamageRate + 
        halidomCrown_mini_CriticalDamageRate;
        return allCriticalDamageRate;
    }
}
