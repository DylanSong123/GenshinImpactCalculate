package calculate;

public class AllHalidomAttackRateClass {
    public double allHalidomAttackRateMain(Double halidom_Main_AttackRate , 
    Double halidomFeather_mini_CriticalRate , Double halidomHourglass_mini_CriticalRate ,
    Double halidomCup_mini_CriticalRate,Double halidomCrown_mini_CriticalRate,
    Double halidomCrown_CriticalRate , double halidomFlower_mini_CriticalRate, 
    double halidomCup_AttackRate){
        double allHalidomAttackRate = halidom_Main_AttackRate + 
        halidomFeather_mini_CriticalRate + halidomHourglass_mini_CriticalRate +
        halidomCup_mini_CriticalRate + halidomCrown_mini_CriticalRate +
        halidomCrown_CriticalRate + halidomFlower_mini_CriticalRate +
        halidomCup_AttackRate;


        return allHalidomAttackRate;
    }
}
