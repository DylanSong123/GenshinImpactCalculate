package calculate;

public class AllExtraDamageClass {
    public double allExtraDamageMain(double weaponFeature_ExtraDamage, 
    double halidom_Main_ExtraDamage, double halidomCup_ExtraDamage, double extraNegativeResistance){
        double allExtraDamage = weaponFeature_ExtraDamage + 
        halidom_Main_ExtraDamage +  halidomCup_ExtraDamage + extraNegativeResistance;
        return allExtraDamage;
    }
}
