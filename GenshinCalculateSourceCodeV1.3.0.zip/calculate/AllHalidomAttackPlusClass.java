package calculate;

public class AllHalidomAttackPlusClass {
    public double allHalidomAttackPlus(Double halidomFlower_mini_AttackGreen, 
    Double halidomFeather_mini_AttackGreen, Double halidomFeather_AttackGreen,
    Double halidomHourglass_mini_AttackGreen, Double halidomCup_mini_AttackGreen, 
    Double halidomCrown_mini_AttackGreen){
        double allAttackGreen = halidomFlower_mini_AttackGreen + 
        halidomFeather_mini_AttackGreen + halidomFeather_AttackGreen + 
        halidomHourglass_mini_AttackGreen + halidomCup_mini_AttackGreen + 
        halidomCrown_mini_AttackGreen;
        return allAttackGreen;
    }
}
