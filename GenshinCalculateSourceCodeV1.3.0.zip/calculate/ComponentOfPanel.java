package calculate;
import java.awt.*;
import javax.swing.*;
public class ComponentOfPanel {
    String primaryData;
    String text01;
    double textNum;
    JTextField textSet = new JTextField(6);
    public int hehe(JPanel panel01, String name, int wordLabelX, int cumulateY, int wordLabelLong, int wordLabelHeigh,
            int cinTextX, int cinTextLong, int cinTextHeigh, int LineSpace) {
        // 面板-panelBaseData-新建组件
        JLabel label01 = new JLabel(name);
        panel01.add(label01);
        label01.setBounds(wordLabelX, cumulateY, wordLabelLong, wordLabelHeigh);
        //JTextField text01 = new JTextField(6);
        panel01.add(textSet);
        textSet.setBounds(cinTextX, cumulateY, cinTextLong, cinTextHeigh);
        cumulateY += LineSpace; // Y轴累加
        // 组件-字体-新建、设置字体
        Font fontBigComponentOfPanel = new Font("黑体", Font.PLAIN, 18);
        Font fontMediumComponentOfPanel = new Font("Arial", Font.PLAIN, 15);
        label01.setFont(fontBigComponentOfPanel);
        textSet.setFont(fontMediumComponentOfPanel);
        // 设置初始值
        textSet.setText(primaryData);
        // 传递数值-textSet
        //if (text01 != null) {
        this.text01 = textSet.getText();
        this.textNum = Double.parseDouble(this.text01);
        //}
        // 返回值
        return cumulateY;
    }
}
