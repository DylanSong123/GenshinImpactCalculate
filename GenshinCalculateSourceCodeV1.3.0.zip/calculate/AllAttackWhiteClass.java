package calculate;

public class AllAttackWhiteClass {
    public double allAttackWhite(Double weaponWhite,Double yourBaseWhite){
        double attackWhite = weaponWhite + yourBaseWhite;
        return attackWhite;
    }
}
