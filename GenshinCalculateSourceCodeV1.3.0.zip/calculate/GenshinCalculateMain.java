package calculate;

import java.awt.*;
import javax.swing.*;
import java.io.*;
/**
 * 
 * GenshinImpactCalculate 
 * 版本V1.3.0 
 * 特性：
 * 新增历史记录功能
 * 新增笔记功能，方便截图记录
 * 
 * 版本V1.2.0 
 * 特性： 更改由属性面板计算，为人物+武器+圣遗物的单独计算，可比较圣遗物的不同带来的差别
 * 将界面大小由700×430改为1000×600 继续调大字体，主要字体更改为黑体18号，次要字体更改为黑体15号加粗 删除History记录面板
 * 
 * 版本V1.1 加入历史记录功能，失败，废弃
 * 
 * 版本V1.0 特性： 优化了界面显示 将界面大小由600×400改为700×430 更改主要文字字体为黑体，15号 更改次要文字字体为黑体，12号，加粗
 * 添加上一次计算记录面板
 */
public class GenshinCalculateMain {
    static String[] strArr;     //HistoryRecord记录传递
    static {
        System.out.println("\n\n开始执行--------V1.2--------\n");
        //预处理-HistoryRecord载入
        String fileNameString = "calculate\\HistoryRecord";
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(fileNameString);
            int fileBytesNum = fis.available();
            System.out.println("HistoryRecord总字节："+ fileBytesNum);      
            byte[] fileBytes = new byte[fileBytesNum];
            fis.read(fileBytes); // 返回字节数量
            String fileBytesString = new String(fileBytes); 
            System.out.println(fileBytesString);
            System.out.println("HistoryRecord已输入完毕");
            String str = fileBytesString; //继承
            String[] strArrs = str.split(",");//分割
            strArr = strArrs;
        } catch (FileNotFoundException throwe) {
                throwe.printStackTrace();
            } catch (IOException throwe) {
                throwe.printStackTrace();
            } finally {
                if (fis != null) {
                    try {
                        fis.close();
                    } catch (IOException throwe) {
                        throwe.printStackTrace();
                    }
                }
            }
    }
    public static void main(String[] args) {
        // 面板统一设置：
        // 面板色彩
        int R = 250;
        int G = 250;
        int B = 250;
        // 面板大小
        int mainLong = 1040;
        int mainHeight = 700;
        // 主窗口-字体-新建字体
        Font fontBig = new Font("黑体", Font.PLAIN, 18);
        Font fontSmall = new Font("黑体", Font.BOLD, 12);
        Font fontEn = new Font("Arial", Font.PLAIN, 15);
        //贯穿星辰的变量
        int cycleI=0;
// =====================================================================================================
        // Main-新建一个主窗口
        JFrame jMainWindows = new JFrame("原神伤害计算器_V1.3.0_酷安@秋日晨曦QY");
        jMainWindows.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); // 主窗口-关闭窗口事件
        jMainWindows.setBounds(100, 100, mainLong, mainHeight); // 主窗口-面板大小
        jMainWindows.setBackground(new Color(200, 200, 200)); // 主窗口-背景颜色-200,200,200
        jMainWindows.setResizable(false); // 主窗口-可见性-不可见
        jMainWindows.setLayout(null); // 主窗口-布局-自定义布局
        // 主窗口-组件-新建按钮-doingButton：计算结果
        JButton doingButton = new JButton("计算");
        doingButton.setBounds(780, 590, 230, 40);
        jMainWindows.add(doingButton);
// =====================================================================================================
        // 主窗口-面板-新建面板-panelBaseData-基础数据
        JPanel panelBaseData = new JPanel();
        panelBaseData.setBounds(5, 5, 250, 75);
        panelBaseData.setBackground(new Color(R, G, B));
        panelBaseData.setLayout(null); // 面板-布局-自定义布局
        jMainWindows.add(panelBaseData);
        // 主窗口-面板-panelBaseData-新建组件
        // 面板-panelBaseData-坐标初始
        int LineSpace = 35; // 每行的距离
        int wordLabelX = 10; // 标题的x轴
        int cinTextX = 120; // 输入框的x轴
        int cumulateY = 10; // 起始y轴
        int wordLabelLong = 120; // 标题长度
        int wordLabelHeigh = 20; // 标题高度
        int cinTextLong = 100; // 输入框长度
        int cinTextHeigh = 28; // 输入框高度
        // 面板-panelBaseData-新建组件-new对象
        ComponentOfPanel yourLevel = new ComponentOfPanel(); // 您的等级
        ComponentOfPanel skillRatio = new ComponentOfPanel(); // 技能倍率
        // 面板-panelBaseData-组件初始值
        yourLevel.primaryData = strArr[cycleI];
        cycleI++;
        skillRatio.primaryData = strArr[cycleI];
        cycleI++;
        // 面板-panelBaseData-新建组件-文字Label&输入框Text
        // 面板-panelBaseData-设置组件-YourLevel
        cumulateY = yourLevel.hehe(panelBaseData, "您的等级", wordLabelX, cumulateY, wordLabelLong, wordLabelHeigh,
                cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        // 面板-panelBaseData-设置组件-SkillRatio
        cumulateY = skillRatio.hehe(panelBaseData, "技能倍率%", wordLabelX, cumulateY, wordLabelLong, wordLabelHeigh,
                cinTextX, cinTextLong, cinTextHeigh, LineSpace);
// =====================================================================================================
        // 主窗口-面板-新建面板-panelBreakthrough-角色突破数据
        JPanel panelBreakthrough = new JPanel();
        panelBreakthrough.setBounds(5, 85, 250, 145);
        panelBreakthrough.setBackground(new Color(R, G, B));
        panelBreakthrough.setLayout(null); // 面板-布局-自定义布局
        jMainWindows.add(panelBreakthrough);
        // 主窗口-面板-panelBreakthrough-新建组件
        // 面板-panelBreakthrough-坐标初始
        LineSpace = 35; // 每行的距离
        wordLabelX = 10; // 标题的x轴
        cinTextX = 160; // 输入框的x轴
        cumulateY = 10; // 起始y轴
        wordLabelLong = 120; // 标题长度
        wordLabelHeigh = 20; // 标题高度
        cinTextLong = 60; // 输入框长度
        cinTextHeigh = 28; // 输入框高度
        // 面板-panelBreakthrough-新建组件-new对象
        ComponentOfPanel yourBaseWhite = new ComponentOfPanel(); // 角色自带白字攻击
        ComponentOfPanel yourCharactersBreakthrough_AttackRate = new ComponentOfPanel(); // 突破攻击加成
        ComponentOfPanel yourCharactersBreakthrough_CriticalRate = new ComponentOfPanel(); // 突破暴击率加成
        ComponentOfPanel yourCharactersBreakthrough_CriticalDamageRate = new ComponentOfPanel(); // 突破爆伤加成
        //yourBaseWhite.textSet.setText(t);
        // 面板-panelBreakthrough-组件初始值
        yourBaseWhite.primaryData  = strArr[cycleI];
        cycleI++;
        yourCharactersBreakthrough_AttackRate.primaryData = strArr[cycleI];
        cycleI++;
        yourCharactersBreakthrough_CriticalRate.primaryData = strArr[cycleI];
        cycleI++;
        yourCharactersBreakthrough_CriticalDamageRate.primaryData = strArr[cycleI];
        cycleI++;
        // 面板-panelBaseData-新建组件-文字Label&输入框Text
        // 面板-panelBaseData-设置组件-yourCharactersBreakthrough
        cumulateY = yourBaseWhite.hehe(panelBreakthrough, "角色自带白字", wordLabelX, cumulateY,
                wordLabelLong, wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = yourCharactersBreakthrough_AttackRate.hehe(panelBreakthrough, "角色攻击加成%", wordLabelX, cumulateY,
                wordLabelLong, wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = yourCharactersBreakthrough_CriticalRate.hehe(panelBreakthrough, "角色暴击加成%", wordLabelX, cumulateY,
                wordLabelLong, wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = yourCharactersBreakthrough_CriticalDamageRate.hehe(panelBreakthrough, "角色爆伤加成%", wordLabelX,
                cumulateY, wordLabelLong, wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
// =====================================================================================================
        // 主窗口-面板-新建面板-panelWeapon-武器数据
        JPanel panelWeapon = new JPanel();
        panelWeapon.setBounds(5, 350, 250, 180);
        panelWeapon.setBackground(new Color(R, G, B));
        panelWeapon.setLayout(null); // 面板-布局-自定义布局
        jMainWindows.add(panelWeapon);
        // 主窗口-面板-panelWeapon-新建组件
        // 面板-panelWeapon-坐标初始
        LineSpace = 35; // 每行的距离
        wordLabelX = 10; // 标题的x轴
        cinTextX = 160; // 输入框的x轴
        cumulateY = 10; // 起始y轴
        wordLabelLong = 120; // 标题长度
        wordLabelHeigh = 20; // 标题高度
        cinTextLong = 60; // 输入框长度
        cinTextHeigh = 28; // 输入框高度
        // 面板-panelWeapon-新建组件-new对象
        ComponentOfPanel weaponWhite = new ComponentOfPanel(); // 武器攻击白字
        ComponentOfPanel weaponFeature_AttackRate = new ComponentOfPanel(); // 武器主词条攻击加成
        ComponentOfPanel weaponFeature_CriticalRate = new ComponentOfPanel(); // 武器主词条暴击加成
        ComponentOfPanel weaponFeature_CriticalDamageRate = new ComponentOfPanel(); // 武器主词条爆伤加成
        ComponentOfPanel weaponFeature_ExtraDamage = new ComponentOfPanel(); // 武器主词条增伤加成
        // 面板-panelWeapon-组件初始值
        weaponWhite.primaryData = strArr[cycleI];
        cycleI++;
        weaponFeature_AttackRate.primaryData = strArr[cycleI];
        cycleI++;
        weaponFeature_CriticalRate.primaryData = strArr[cycleI];
        cycleI++;
        weaponFeature_CriticalDamageRate.primaryData = strArr[cycleI];
        cycleI++;
        weaponFeature_ExtraDamage.primaryData = strArr[cycleI];
        cycleI++;
        // 面板-panelBaseData-新建组件-文字Label&输入框Text
        // 面板-panelBaseData-设置组件-yourCharactersBreakthrough
        cumulateY = weaponWhite.hehe(panelWeapon, "武器攻击白字", wordLabelX, cumulateY, wordLabelLong, wordLabelHeigh,
                cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = weaponFeature_AttackRate.hehe(panelWeapon, "武器攻击加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = weaponFeature_CriticalRate.hehe(panelWeapon, "武器暴击加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = weaponFeature_CriticalDamageRate.hehe(panelWeapon, "武器爆伤加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = weaponFeature_ExtraDamage.hehe(panelWeapon, "武器增伤加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
// =====================================================================================================
        // 主窗口-面板-新建面板-panelEnemy-敌人数据
        JPanel panelEnemy = new JPanel();
        panelEnemy.setBounds(5, 235, 250, 110);
        panelEnemy.setBackground(new Color(R, G, B));
        panelEnemy.setLayout(null); // 面板-布局-自定义布局
        jMainWindows.add(panelEnemy);
        // 主窗口-面板-panelEnemy-新建组件
        // 面板-panelEnemy-坐标初始
        LineSpace = 35; // 每行的距离
        wordLabelX = 10; // 标题的x轴
        cinTextX = 120; // 输入框的x轴
        cumulateY = 10; // 起始y轴
        wordLabelLong = 120; // 标题长度
        wordLabelHeigh = 20; // 标题高度
        cinTextLong = 100; // 输入框长度
        cinTextHeigh = 28; // 输入框高度
        // 面板-panelEnemy-新建组件-new对象
        ComponentOfPanel enemyLevel = new ComponentOfPanel(); // 武器攻击白字
        ComponentOfPanel enemyResistance = new ComponentOfPanel(); // 武器主词条攻击加成
        ComponentOfPanel extraNegativeResistance = new ComponentOfPanel();//负抗增伤
        // 面板-panelEnemy-组件初始值
        enemyLevel.primaryData = strArr[cycleI];
        cycleI++;
        enemyResistance.primaryData = strArr[cycleI];
        cycleI++;
        extraNegativeResistance.primaryData = strArr[42];
        // 面板-panelBaseData-新建组件-文字Label&输入框Text
        // 面板-panelBaseData-设置组件-yourCharactersBreakthrough
        cumulateY = enemyLevel.hehe(panelEnemy, "敌人等级", wordLabelX, cumulateY, wordLabelLong, wordLabelHeigh, cinTextX,
                cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = enemyResistance.hehe(panelEnemy, "敌人抗性", wordLabelX, cumulateY, wordLabelLong, wordLabelHeigh,
                cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = extraNegativeResistance.hehe(panelEnemy, "负抗增伤%", wordLabelX, cumulateY, wordLabelLong, wordLabelHeigh,
                cinTextX, cinTextLong, cinTextHeigh, LineSpace);
// =====================================================================================================
        // 主窗口-面板-新建面板-panelHalidomMain-圣遗物总面板
        JPanel panelHalidomMain = new JPanel();
        panelHalidomMain.setBounds(260, 5, 250, 145);
        panelHalidomMain.setBackground(new Color(R, G, B));
        panelHalidomMain.setLayout(null); // 面板-布局-自定义布局
        jMainWindows.add(panelHalidomMain);
        // 主窗口-面板-panelHalidomMain-新建组件
        // 面板-panelHalidomMain-标题
        TheLabel halidomMainLabel = new TheLabel();
        halidomMainLabel.heheda(panelHalidomMain, "圣遗物套装加成", 5, 15, 150, 30);
        // 面板-panelHalidomMain-坐标初始
        LineSpace = 35; // 每行的距离
        wordLabelX = 10; // 标题的x轴
        cinTextX = 180; // 输入框的x轴
        cumulateY = 40; // 起始y轴
        wordLabelLong = 120; // 标题长度
        wordLabelHeigh = 20; // 标题高度
        cinTextLong = 60; // 输入框长度
        cinTextHeigh = 28; // 输入框高度
        // 面板-panelHalidomMain-新建组件-new对象
        ComponentOfPanel halidom_Main_AttackRate = new ComponentOfPanel(); // 圣遗物套装攻击加成
        ComponentOfPanel halidom_Main_CriticalRate = new ComponentOfPanel(); // 圣遗物套装暴击加成
        ComponentOfPanel halidom_Main_ExtraDamage = new ComponentOfPanel(); // 圣遗物套装增伤加成
        // 面板-panelHalidomMain-组件初始值
        halidom_Main_AttackRate.primaryData = strArr[cycleI];
        cycleI++;
        halidom_Main_CriticalRate.primaryData = strArr[cycleI];
        cycleI++;
        halidom_Main_ExtraDamage.primaryData = strArr[cycleI];
        cycleI++;
        // 面板-panelBaseData-新建组件-文字Label&输入框Text
        // 面板-panelBaseData-设置组件-yourCharactersBreakthrough
        cumulateY = halidom_Main_AttackRate.hehe(panelHalidomMain, "套装攻击加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidom_Main_CriticalRate.hehe(panelHalidomMain, "套装暴击加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidom_Main_ExtraDamage.hehe(panelHalidomMain, "套装增伤加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
// =====================================================================================================
        // 主窗口-面板-新建面板-panelHalidomFlower-生之花圣遗物
        JPanel panelHalidomFlower = new JPanel();
        panelHalidomFlower.setBounds(260, 155, 250, 175);
        panelHalidomFlower.setBackground(new Color(R, G, B));
        panelHalidomFlower.setLayout(null); // 面板-布局-自定义布局
        jMainWindows.add(panelHalidomFlower);
        // 主窗口-面板-panelHalidomFlower-新建组件
        // 面板-panelHalidomFlower-标题
        TheLabel halidomFlowerLabel = new TheLabel();
        halidomFlowerLabel.heheda(panelHalidomFlower, "生之花加成", 5, 15, 150, 30);
        // 面板-panelHalidomFlower-坐标初始
        LineSpace = 35; // 每行的距离
        wordLabelX = 10; // 标题的x轴
        cinTextX = 180; // 输入框的x轴
        cumulateY = 40; // 起始y轴
        wordLabelLong = 160; // 标题长度
        wordLabelHeigh = 20; // 标题高度
        cinTextLong = 60; // 输入框长度
        cinTextHeigh = 28; // 输入框高度
        // 面板-panelHalidomFlower-新建组件-new对象
        ComponentOfPanel halidomFlower_mini_AttackGreen = new ComponentOfPanel(); // 攻击绿字
        ComponentOfPanel halidomFlower_mini_AttackRate = new ComponentOfPanel(); // 攻击绿字百分比
        ComponentOfPanel halidomFlower_mini_CriticalRate = new ComponentOfPanel(); // 暴击加成
        ComponentOfPanel halidomFlower_mini_CriticalDamageRate = new ComponentOfPanel(); // 爆伤加成
        // 面板-panelHalidomFlower-组件初始值
        halidomFlower_mini_AttackGreen.primaryData = strArr[cycleI];
        cycleI++;
        halidomFlower_mini_AttackRate.primaryData = strArr[cycleI];
        cycleI++;
        halidomFlower_mini_CriticalRate.primaryData = strArr[cycleI];
        cycleI++;
        halidomFlower_mini_CriticalDamageRate.primaryData = strArr[cycleI];
        cycleI++; 
        // 面板-panelBaseData-新建组件-文字Label&输入框Text
        // 面板-panelBaseData-设置组件-yourCharactersBreakthrough
        cumulateY = halidomFlower_mini_AttackGreen.hehe(panelHalidomFlower, "攻击+", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomFlower_mini_AttackRate.hehe(panelHalidomFlower, "攻击百分比%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomFlower_mini_CriticalRate.hehe(panelHalidomFlower, "暴击加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomFlower_mini_CriticalDamageRate.hehe(panelHalidomFlower, "爆伤加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
// =====================================================================================================
        // 主窗口-面板-新建面板-panelHalidomFeather-死之羽圣遗物
        JPanel panelHalidomFeather = new JPanel();
        panelHalidomFeather.setBounds(260, 335, 250, 210); //515+250+5//770+250+5=1025//155+145+5=305
        panelHalidomFeather.setBackground(new Color(R, G, B));
        panelHalidomFeather.setLayout(null); // 面板-布局-自定义布局
        jMainWindows.add(panelHalidomFeather);
        // 主窗口-面板-panelHalidomFeather-新建组件
        // 面板-panelHalidomFeather-标题
        TheLabel halidomFeatherLabel = new TheLabel();
        halidomFeatherLabel.heheda(panelHalidomFeather, "死之羽加成", 5, 15, 150, 30);
        // 面板-panelHalidomFeather-坐标初始
        LineSpace = 35; // 每行的距离
        wordLabelX = 10; // 标题的x轴
        cinTextX = 180; // 输入框的x轴
        cumulateY = 40; // 起始y轴
        wordLabelLong = 160; // 标题长度
        wordLabelHeigh = 20; // 标题高度
        cinTextLong = 60; // 输入框长度
        cinTextHeigh = 28; // 输入框高度
        // 面板-panelHalidomFeather-新建组件-new对象
        ComponentOfPanel halidomFeather_AttackGreen = new ComponentOfPanel(); // 攻击主词条
        ComponentOfPanel halidomFeather_mini_AttackGreen = new ComponentOfPanel(); // 攻击绿字
        ComponentOfPanel halidomFeather_mini_AttackRate = new ComponentOfPanel(); // 攻击绿字百分比
        ComponentOfPanel halidomFeather_mini_CriticalRate = new ComponentOfPanel(); // 暴击加成
        ComponentOfPanel halidomFeather_mini_CriticalDamageRate = new ComponentOfPanel(); // 爆伤加成
        // 面板-panelHalidomFeather-组件初始值
        halidomFeather_AttackGreen.primaryData = strArr[cycleI];
        cycleI++;
        halidomFeather_mini_AttackGreen.primaryData = strArr[cycleI];
        cycleI++;
        halidomFeather_mini_AttackRate.primaryData = strArr[cycleI];
        cycleI++;
        halidomFeather_mini_CriticalRate.primaryData = strArr[cycleI];
        cycleI++;
        halidomFeather_mini_CriticalDamageRate.primaryData = strArr[cycleI];
        cycleI++;
        // 面板-panelBaseData-新建组件-文字Label&输入框Text
        // 面板-panelBaseData-设置组件-yourCharactersBreakthrough
        cumulateY = halidomFeather_AttackGreen.hehe(panelHalidomFeather, "攻击主词条+", wordLabelX, cumulateY, wordLabelLong,
            wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomFeather_mini_AttackGreen.hehe(panelHalidomFeather, "攻击+", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomFeather_mini_AttackRate.hehe(panelHalidomFeather, "攻击百分比%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomFeather_mini_CriticalRate.hehe(panelHalidomFeather, "暴击加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomFeather_mini_CriticalDamageRate.hehe(panelHalidomFeather, "爆伤加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
// =====================================================================================================
        // 主窗口-面板-新建面板-panelHalidomHourglass-时之沙圣遗物
        JPanel panelHalidomHourglass = new JPanel();
        panelHalidomHourglass.setBounds(515, 5, 250, 210); //155+175+5=335
        panelHalidomHourglass.setBackground(new Color(R, G, B));
        panelHalidomHourglass.setLayout(null); // 面板-布局-自定义布局
        jMainWindows.add(panelHalidomHourglass);
        // 主窗口-面板-panelHalidomHourglass-新建组件
        // 面板-panelHalidomHourglass-标题
        TheLabel halidomHourglassLabel = new TheLabel();
        halidomHourglassLabel.heheda(panelHalidomHourglass, "时之沙加成", 5, 15, 150, 30);
        // 面板-panelHalidomHourglass-坐标初始
        LineSpace = 35; // 每行的距离
        wordLabelX = 10; // 标题的x轴
        cinTextX = 180; // 输入框的x轴
        cumulateY = 40; // 起始y轴
        wordLabelLong = 160; // 标题长度
        wordLabelHeigh = 20; // 标题高度
        cinTextLong = 60; // 输入框长度
        cinTextHeigh = 28; // 输入框高度
        // 面板-panelHalidomHourglass-新建组件-new对象
        ComponentOfPanel halidomHourglass_AttackRate = new ComponentOfPanel(); // 攻击百分比主词条
        ComponentOfPanel halidomHourglass_mini_AttackGreen = new ComponentOfPanel(); // 攻击绿字
        ComponentOfPanel halidomHourglass_mini_AttackRate = new ComponentOfPanel(); // 攻击绿字百分比
        ComponentOfPanel halidomHourglass_mini_CriticalRate = new ComponentOfPanel(); // 暴击加成
        ComponentOfPanel halidomHourglass_mini_CriticalDamageRate = new ComponentOfPanel(); // 爆伤加成
        // 面板-panelHalidomHourglass-组件初始值
        halidomHourglass_AttackRate.primaryData = strArr[cycleI];
        cycleI++;
        halidomHourglass_mini_AttackGreen.primaryData = strArr[cycleI];
        cycleI++;
        halidomHourglass_mini_AttackRate.primaryData = strArr[cycleI];
        cycleI++;
        halidomHourglass_mini_CriticalRate.primaryData = strArr[cycleI];
        cycleI++;
        halidomHourglass_mini_CriticalDamageRate.primaryData = strArr[cycleI];
        cycleI++;
        // 面板-panelBaseData-新建组件-文字Label&输入框Text
        // 面板-panelBaseData-设置组件-yourCharactersBreakthrough
        cumulateY = halidomHourglass_AttackRate.hehe(panelHalidomHourglass, "攻击百分比主词条%", wordLabelX, cumulateY, wordLabelLong,
            wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomHourglass_mini_AttackGreen.hehe(panelHalidomHourglass, "攻击+", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomHourglass_mini_AttackRate.hehe(panelHalidomHourglass, "攻击百分比%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomHourglass_mini_CriticalRate.hehe(panelHalidomHourglass, "暴击加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomHourglass_mini_CriticalDamageRate.hehe(panelHalidomHourglass, "爆伤加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
// =====================================================================================================
        // 主窗口-面板-新建面板-panelHalidomCup-空之杯圣遗物
        JPanel panelHalidomCup = new JPanel();
        panelHalidomCup.setBounds(515, 220, 250, 245); //155+175+5=335
        panelHalidomCup.setBackground(new Color(R, G, B));
        panelHalidomCup.setLayout(null); // 面板-布局-自定义布局
        jMainWindows.add(panelHalidomCup);
        // 主窗口-面板-panelHalidomCup-新建组件
        // 面板-panelHalidomCup-标题
        TheLabel halidomCupLabel = new TheLabel();
        halidomCupLabel.heheda(panelHalidomCup, "空之杯加成", 5, 15, 150, 30);
        // 面板-panelHalidomCup-坐标初始
        LineSpace = 35; // 每行的距离
        wordLabelX = 10; // 标题的x轴
        cinTextX = 180; // 输入框的x轴
        cumulateY = 40; // 起始y轴
        wordLabelLong = 160; // 标题长度
        wordLabelHeigh = 20; // 标题高度
        cinTextLong = 60; // 输入框长度
        cinTextHeigh = 28; // 输入框高度
        // 面板-panelHalidomCup-新建组件-new对象
        ComponentOfPanel halidomCup_AttackRate = new ComponentOfPanel(); // 攻击百分比主词条
        ComponentOfPanel halidomCup_ExtraDamage = new ComponentOfPanel(); // 增伤百分比主词条
        ComponentOfPanel halidomCup_mini_AttackGreen = new ComponentOfPanel(); // 攻击绿字
        ComponentOfPanel halidomCup_mini_AttackRate = new ComponentOfPanel(); // 攻击绿字百分比
        ComponentOfPanel halidomCup_mini_CriticalRate = new ComponentOfPanel(); // 暴击加成
        ComponentOfPanel halidomCup_mini_CriticalDamageRate = new ComponentOfPanel(); // 爆伤加成
        // 面板-panelHalidomCup-组件初始值
        halidomCup_AttackRate.primaryData = strArr[cycleI];
        cycleI++;
        halidomCup_ExtraDamage.primaryData = strArr[cycleI];
        cycleI++;
        halidomCup_mini_AttackGreen.primaryData = strArr[cycleI];
        cycleI++;
        halidomCup_mini_AttackRate.primaryData = strArr[cycleI];
        cycleI++;
        halidomCup_mini_CriticalRate.primaryData = strArr[cycleI];
        cycleI++;
        halidomCup_mini_CriticalDamageRate.primaryData = strArr[cycleI];
        cycleI++;
        // 面板-panelBaseData-新建组件-文字Label&输入框Text
        // 面板-panelBaseData-设置组件-yourCharactersBreakthrough
        cumulateY = halidomCup_AttackRate.hehe(panelHalidomCup, "攻击百分比主词条%", wordLabelX, cumulateY, wordLabelLong,
            wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomCup_ExtraDamage.hehe(panelHalidomCup, "增伤百分比主词条%", wordLabelX, cumulateY, wordLabelLong,
            wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomCup_mini_AttackGreen.hehe(panelHalidomCup, "攻击+", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomCup_mini_AttackRate.hehe(panelHalidomCup, "攻击百分比%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomCup_mini_CriticalRate.hehe(panelHalidomCup, "暴击加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomCup_mini_CriticalDamageRate.hehe(panelHalidomCup, "爆伤加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
// =====================================================================================================
        // 主窗口-面板-新建面板-panelHalidomCrown-理之冠圣遗物
        JPanel panelHalidomCrown = new JPanel();
        panelHalidomCrown.setBounds(770, 5, 250, 245); //155+175+5=335
        panelHalidomCrown.setBackground(new Color(R, G, B));
        panelHalidomCrown.setLayout(null); // 面板-布局-自定义布局
        jMainWindows.add(panelHalidomCrown);
        // 主窗口-面板-panelHalidomCrown-新建组件
        // 面板-panelHalidomCrown-标题
        TheLabel halidomCrownLabel = new TheLabel();
        halidomCrownLabel.heheda(panelHalidomCrown, "理之冠加成", 5, 15, 150, 30);
        // 面板-panelHalidomCrown-坐标初始
        LineSpace = 35; // 每行的距离
        wordLabelX = 10; // 标题的x轴
        cinTextX = 180; // 输入框的x轴
        cumulateY = 40; // 起始y轴
        wordLabelLong = 160; // 标题长度
        wordLabelHeigh = 20; // 标题高度
        cinTextLong = 60; // 输入框长度
        cinTextHeigh = 28; // 输入框高度
        // 面板-panelHalidomCrown-新建组件-new对象
        ComponentOfPanel halidomCrown_CriticalRate = new ComponentOfPanel(); // 暴击百分比主词条
        ComponentOfPanel halidomCrown_CriticalDamageRate = new ComponentOfPanel(); // 爆伤百分比主词条
        ComponentOfPanel halidomCrown_mini_AttackGreen = new ComponentOfPanel(); // 攻击绿字
        ComponentOfPanel halidomCrown_mini_AttackRate = new ComponentOfPanel(); // 攻击绿字百分比
        ComponentOfPanel halidomCrown_mini_CriticalRate = new ComponentOfPanel(); // 暴击加成
        ComponentOfPanel halidomCrown_mini_CriticalDamageRate = new ComponentOfPanel(); // 爆伤加成
        // 面板-panelHalidomCrown-组件初始值
        halidomCrown_CriticalRate.primaryData = strArr[cycleI];
        cycleI++;
        halidomCrown_CriticalDamageRate.primaryData = strArr[cycleI];
        cycleI++;
        halidomCrown_mini_AttackGreen.primaryData = strArr[cycleI];
        cycleI++;
        halidomCrown_mini_AttackRate.primaryData = strArr[cycleI];
        cycleI++;
        halidomCrown_mini_CriticalRate.primaryData = strArr[cycleI];
        cycleI++;
        halidomCrown_mini_CriticalDamageRate.primaryData = strArr[cycleI];
        cycleI++;
        // 面板-panelBaseData-新建组件-文字Label&输入框Text
        // 面板-panelBaseData-设置组件-yourCharactersBreakthrough
        cumulateY = halidomCrown_CriticalRate.hehe(panelHalidomCrown, "暴击加成主词条%", wordLabelX, cumulateY, wordLabelLong,
            wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomCrown_CriticalDamageRate.hehe(panelHalidomCrown, "爆伤加成主词条%", wordLabelX, cumulateY, wordLabelLong,
            wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomCrown_mini_AttackGreen.hehe(panelHalidomCrown, "攻击+", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomCrown_mini_AttackRate.hehe(panelHalidomCrown, "攻击百分比%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomCrown_mini_CriticalRate.hehe(panelHalidomCrown, "暴击加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
        cumulateY = halidomCrown_mini_CriticalDamageRate.hehe(panelHalidomCrown, "爆伤加成%", wordLabelX, cumulateY, wordLabelLong,
                wordLabelHeigh, cinTextX, cinTextLong, cinTextHeigh, LineSpace);
// =====================================================================================================
        // 主窗口-面板-新建面板-panelConsole-终端
        JPanel panelConsole = new JPanel();
        panelConsole.setBounds(770, 510, 250, 75);//270+110=380//380-305=75
        panelConsole.setBackground(new Color(R, G, B));
        panelConsole.setLayout(null); // 面板-布局-自定义布局
        jMainWindows.add(panelConsole);
        // 主窗口-面板-panelConsole-新建组件
        // 面板-panelConsole-新建组件-new对象
        theConsole theConsoles = new theConsole(); // 终端
        // 面板-panelConsole-组件初始值
        theConsoles.primaryData = "控制台:请输入计算内容";
        // 面板-panelBaseData-新建组件-文字Label&输入框Text
        // 面板-panelBaseData-设置组件-yourCharactersBreakthrough
        theConsoles.hehe(panelConsole, "控制台", 10, 10, 230, 60);
// =====================================================================================================
        // 主窗口-面板-新建面板-panelWordRecord-题词板
        JPanel panelWordRecord = new JPanel();
        panelWordRecord.setBounds(515, 470, 250, 75);//270+110=380//380-305=75
        panelWordRecord.setBackground(new Color(R, G, B));
        panelWordRecord.setLayout(null); // 面板-布局-自定义布局
        jMainWindows.add(panelWordRecord);
        // 主窗口-面板-panelWordRecord-新建组件
        // 面板-panelWordRecord-新建组件-new对象
        theConsole wordRecord = new theConsole(); // 终端
        // 面板-panelWordRecord-组件初始值
        wordRecord.primaryData = "笔记：";
        // 面板-panelBaseData-新建组件-文字Label&输入框Text
        // 面板-panelBaseData-设置组件-yourCharactersBreakthrough
        wordRecord.hehe(panelWordRecord, "控制台", 10, 10, 230, 60);
// =====================================================================================================
        // 主窗口-面板-新建面板-panelResult-结果面板
        JPanel panelResult = new JPanel();
        panelResult.setBounds(770, 255, 250, 250);
        panelResult.setBackground(new Color(R, G, B));
        panelResult.setLayout(null); // 面板-布局-自定义布局
        jMainWindows.add(panelResult);
        // 主窗口-面板-panelResult-新建组件
        // 面板-panelResult-坐标初始
        LineSpace = 35; // 每行的距离
        wordLabelX = 10; // 标题的x轴
        cinTextX = 140; // 输入框的x轴
        cumulateY = 10; // 起始y轴
        wordLabelLong = 120; // 标题长度
        wordLabelHeigh = 20; // 标题高度
        cinTextLong = 100; // 输入框长度
        cinTextHeigh = 28; // 输入框高度
//=============
        // 主窗口-面板-新建面板-panelResult-结果面板2
        JLabel label01 = new JLabel("攻击白字");
        panelResult.add(label01);
        label01.setBounds(wordLabelX, cumulateY, wordLabelLong, wordLabelHeigh);
        JTextField attackWhite = new JTextField(6);
        panelResult.add(attackWhite);
        attackWhite.setBounds(cinTextX, cumulateY, cinTextLong, cinTextHeigh);
        cumulateY += LineSpace; // Y轴累加
        attackWhite.setText("Null");
        JLabel label02 = new JLabel("攻击绿字");
        panelResult.add(label02);
        label02.setBounds(wordLabelX, cumulateY, wordLabelLong, wordLabelHeigh);
        JTextField attackGreen = new JTextField(6);
        panelResult.add(attackGreen);
        attackGreen.setBounds(cinTextX, cumulateY, cinTextLong, cinTextHeigh);
        cumulateY += LineSpace; // Y轴累加
        attackGreen.setText("Null");
        JLabel label03 = new JLabel("暴击率%");
        panelResult.add(label03);
        label03.setBounds(wordLabelX, cumulateY, wordLabelLong, wordLabelHeigh);
        JTextField criticalRate = new JTextField(6);
        panelResult.add(criticalRate);
        criticalRate.setBounds(cinTextX, cumulateY, cinTextLong, cinTextHeigh);
        cumulateY += LineSpace; // Y轴累加
        criticalRate.setText("Null");
        JLabel label04 = new JLabel("暴击伤害%");
        panelResult.add(label04);
        label04.setBounds(wordLabelX, cumulateY, wordLabelLong, wordLabelHeigh);
        JTextField criticalDamageRate = new JTextField(6);
        panelResult.add(criticalDamageRate);
        criticalDamageRate.setBounds(cinTextX, cumulateY, cinTextLong, cinTextHeigh);
        cumulateY += LineSpace; // Y轴累加
        criticalDamageRate.setText("Null");
        JLabel label05 = new JLabel("单次基础伤害");
        panelResult.add(label05);
        label05.setBounds(wordLabelX, cumulateY, wordLabelLong, wordLabelHeigh);
        JTextField onceStrikeDamage = new JTextField(6);
        panelResult.add(onceStrikeDamage);
        onceStrikeDamage.setBounds(cinTextX, cumulateY, cinTextLong, cinTextHeigh);
        cumulateY += LineSpace; // Y轴累加
        onceStrikeDamage.setText("Null");
        JLabel label06 = new JLabel("单次暴击伤害");
        panelResult.add(label06);
        label06.setBounds(wordLabelX, cumulateY, wordLabelLong, wordLabelHeigh);
        JTextField onceCriticalDamage = new JTextField(6);
        panelResult.add(onceCriticalDamage);
        onceCriticalDamage.setBounds(cinTextX, cumulateY, cinTextLong, cinTextHeigh);
        cumulateY += LineSpace; // Y轴累加
        onceCriticalDamage.setText("Null");
        JLabel label07 = new JLabel("单次期望伤害");
        panelResult.add(label07);
        label07.setBounds(wordLabelX, cumulateY, wordLabelLong, wordLabelHeigh);
        JTextField singleExpectedDamage = new JTextField(6);
        panelResult.add(singleExpectedDamage);
        singleExpectedDamage.setBounds(cinTextX, cumulateY, cinTextLong, cinTextHeigh);
        cumulateY += LineSpace; // Y轴累加
        singleExpectedDamage.setText("Null");
// =====================================================================================================
        // 主窗口-组件-新建文字Label-计算公式说明
        int startGapSpaceLabel = 180;
        int GapSpaceLabel = 15;
        JLabel labelmainsF01 = new JLabel("等级差距系数=0.002940（我估算的）");
        jMainWindows.add(labelmainsF01);
        labelmainsF01.setBounds(5, mainHeight-startGapSpaceLabel+GapSpaceLabel, 800, 30);
        JLabel labelmains0 = new JLabel("基础伤害=0.5×[(白字+绿字)×(1-抗性)×(1+增伤)×技能倍率×(1+等级差距×等级差距系数)]");
        jMainWindows.add(labelmains0);
        labelmains0.setBounds(5, mainHeight-startGapSpaceLabel+GapSpaceLabel*2, 800, 30);
        JLabel labelmains1 = new JLabel("暴击伤害=单次基础伤害×(1+暴击伤害)");
        jMainWindows.add(labelmains1);
        labelmains1.setBounds(5, mainHeight-startGapSpaceLabel+GapSpaceLabel*3, 800, 30);
        JLabel labelmains2 = new JLabel("期望伤害=单次基础伤害×(1-暴击率)+单次暴击伤害×暴击率");
        jMainWindows.add(labelmains2);
        labelmains2.setBounds(5, mainHeight-startGapSpaceLabel+GapSpaceLabel*4, 900, 30);
        JLabel labelmains305 = new JLabel("攻击白字=人物基础白字+武器白字(不知道自己基础白字的，用面板的白字-武器的白字)");
        jMainWindows.add(labelmains305);
        labelmains305.setBounds(5, mainHeight-startGapSpaceLabel+GapSpaceLabel*5, 900, 30);
        JLabel labelmains3 = new JLabel("攻击绿字=死之羽攻击+圣遗物小词条攻击+攻击白字×(人物突破/武器/圣遗物套装/圣遗物主词条/小词条攻击百分比加成)");
        jMainWindows.add(labelmains3);
        labelmains3.setBounds(5, mainHeight-startGapSpaceLabel+GapSpaceLabel*6, 900, 30);
        JLabel labelmains4 = new JLabel("对于抗性与减抗，如果低于0，则按照多余出来的减抗×0.5转换为增伤;如：减抗40%，抗性是10%，则抗性减到0，然后剩余30%*0.5=15%增伤");
        jMainWindows.add(labelmains4);
        labelmains4.setBounds(5, mainHeight-startGapSpaceLabel+GapSpaceLabel*7, 1000, 30);
// =====================================================================================================
        // Main-字体-设置字体-按钮
        doingButton.setFont(fontBig);
        // Main-字体-设置字体-计算公式说明
        labelmainsF01.setFont(fontSmall);
        labelmains0.setFont(fontSmall);
        labelmains1.setFont(fontSmall);
        labelmains2.setFont(fontSmall);
        labelmains305.setFont(fontSmall);
        labelmains3.setFont(fontSmall);
        labelmains4.setFont(fontSmall);
        // Main-字体-设置字体-结果面板
        label01.setFont(fontBig);
        label02.setFont(fontBig);
        label03.setFont(fontBig);
        label04.setFont(fontBig);
        label05.setFont(fontBig);
        label06.setFont(fontBig);
        label07.setFont(fontBig);
        attackWhite.setFont(fontEn);
        attackGreen.setFont(fontEn);
        criticalRate.setFont(fontEn);
        criticalDamageRate.setFont(fontEn);
        onceStrikeDamage.setFont(fontEn);
        onceCriticalDamage.setFont(fontEn);
        singleExpectedDamage.setFont(fontEn);
        // 主窗口-显示主窗口
        jMainWindows.setVisible(true);
        // Main-调用监听
        MyCaluculatorListening doingListener = new MyCaluculatorListening(yourLevel.textSet, skillRatio.textSet, yourBaseWhite.textSet, yourCharactersBreakthrough_AttackRate.textSet, yourCharactersBreakthrough_CriticalRate.textSet, yourCharactersBreakthrough_CriticalDamageRate.textSet, weaponWhite.textSet, weaponFeature_AttackRate.textSet, weaponFeature_CriticalRate.textSet, weaponFeature_CriticalDamageRate.textSet, weaponFeature_ExtraDamage.textSet, enemyLevel.textSet, enemyResistance.textSet, halidom_Main_AttackRate.textSet, halidom_Main_CriticalRate.textSet, halidom_Main_ExtraDamage.textSet, halidomFlower_mini_AttackGreen.textSet, halidomFlower_mini_AttackRate.textSet, halidomFlower_mini_CriticalRate.textSet, halidomFlower_mini_CriticalDamageRate.textSet, halidomFeather_AttackGreen.textSet, halidomFeather_mini_AttackGreen.textSet, halidomFeather_mini_AttackRate.textSet, halidomFeather_mini_CriticalRate.textSet, halidomFeather_mini_CriticalDamageRate.textSet, halidomHourglass_AttackRate.textSet, halidomHourglass_mini_AttackGreen.textSet, halidomHourglass_mini_AttackRate.textSet, halidomHourglass_mini_CriticalRate.textSet, halidomHourglass_mini_CriticalDamageRate.textSet, halidomCup_AttackRate.textSet, halidomCup_ExtraDamage.textSet, halidomCup_mini_AttackGreen.textSet, halidomCup_mini_AttackRate.textSet, halidomCup_mini_CriticalRate.textSet, halidomCup_mini_CriticalDamageRate.textSet, halidomCrown_CriticalRate.textSet, halidomCrown_CriticalDamageRate.textSet, halidomCrown_mini_AttackGreen.textSet, halidomCrown_mini_AttackRate.textSet, halidomCrown_mini_CriticalRate.textSet, halidomCrown_mini_CriticalDamageRate.textSet,onceStrikeDamage,onceCriticalDamage,singleExpectedDamage,attackWhite,attackGreen,criticalRate,criticalDamageRate,theConsoles.text01,extraNegativeResistance.textSet); 
        doingButton.addActionListener(doingListener);
    }
}