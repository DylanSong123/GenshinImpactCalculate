package calculate;

import java.awt.*;
import javax.swing.*;
//import java.awt.event.*;

public class theConsole {
    String primaryData;
    //JTextField text01;
    JTextField text01  = new JTextField(6);
    public void hehe(JPanel panel01, String name, int Y, int X, int Long, int Heigh) {
        // 面板-panelBaseData-新建组件

        panel01.add(text01);
        text01.setBounds(X, Y, Long, Heigh);
        // 组件-字体-新建、设置字体
        Font fontBigtheConsole = new Font("黑体", Font.BOLD, 15);
        text01.setFont(fontBigtheConsole);
        // 设置初始值
        text01.setText(primaryData);
    }
}
