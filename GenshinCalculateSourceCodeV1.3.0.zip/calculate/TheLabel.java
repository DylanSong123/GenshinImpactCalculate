package calculate;
import java.awt.*;
import javax.swing.*;
//import java.awt.event.*;
public class TheLabel {
    public void heheda(JPanel panel01, String name, int cumulateY, int cinTextX, int cinTextLong, int cinTextHeigh) {
        // 面板-panelBaseData-新建组件
        JLabel label012 = new JLabel(name);
        label012.setBounds(cinTextX, cumulateY, cinTextLong, cinTextHeigh);
        panel01.add(label012);
        // 组件-字体-新建、设置字体
        Font fontBigTheLabel = new Font("黑体", Font.BOLD, 15);
        label012.setFont(fontBigTheLabel);
    }
}
