package calculate;

public class AllAttackGreenClass {
    public double allAttackGreenMain(Double allAttackWhite, 
    Double yourCharactersBreakthrough_AttackRate, Double weaponFeature_AttackRate,
    Double allHalidomAttackRate, Double allHalidomAttackPlus){
        double allAttackGreen = allAttackWhite * 
        (yourCharactersBreakthrough_AttackRate + weaponFeature_AttackRate + allHalidomAttackRate)+
        allHalidomAttackPlus;
        return allAttackGreen;
    }
}
